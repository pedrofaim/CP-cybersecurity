# Caminho mais rápido para abrir

1. Instale Python 3.11, 3.12 ou 3.13 (64 bits), se ainda não tiver. Inclua o launcher e a opção Add python.exe to PATH.
2. Extraia todo o ZIP. Abra `sentinel-sast` e dê dois cliques em **ABRIR-SENTINEL.bat**. (Opcional, uma vez só: **CRIAR-ATALHO-DESKTOP.bat** cria o atalho "Sentinel SAST" na área de trabalho.)
3. Aguarde a instalação automática. O navegador abre em **http://localhost:8765** e a **chave de acesso já está copiada** — cole com Ctrl+V no painel. Deixe a janela aberta.
4. Clique **Experimentar laboratório**. O motor calcula 14 achados em quatro linguagens.

Não abra `web/index.html` diretamente: a aplicação precisa da API. Para ler instruções sem servidor, abra `COMECE_AQUI.html`.

**Arquivo único:** se você recebeu `ABRIR_SENTINEL_FINAL.bat`, basta abri-lo após instalar Python 3.12. Ele prepara o projeto em `%LOCALAPPDATA%\SentinelSAST\sentinel-sast` e inicia o mesmo modo local. Sua chave também fica no `.env` dessa pasta. Não confunda com o `.env` de uma cópia antiga em Downloads.

## Validar e demonstrar a arquitetura completa

- `VALIDAR_TUDO.bat` executa testes, Bandit, autoanálise e os controles.
- `INICIAR_COM_DOCKER.bat` inicia API + PostgreSQL + Redis + Celery em localhost:8000.
- `ATIVAR_IA.bat` adiciona Ollama e baixa o modelo. No modo Docker a IA é acessível pelo worker, sem publicar porta do Ollama.
- No painel DevSecOps, **Verificar Ollama** consulta o modelo instalado. Marque **Revisar com IA local** ao criar uma análise.
- Com Ollama nativo na porta 11434 e dependências locais instaladas: `.\.venv\Scripts\python.exe scripts/smoke_ai.py` salva evidência real. No Docker, use uma análise pela API/painel e exporte o JSON para demonstrar a resposta do worker.

## Se não abrir

- **Janela fecha:** abra Terminal na pasta do projeto e execute `py -3.12 scripts/start_windows.py --mode local --port 8765`; a mensagem fica visível.
- **Python não encontrado:** confirme `py -3.12 --version`; use o instalador oficial em https://www.python.org/downloads/windows/.
- **Porta ocupada:** feche o iniciador antigo ou execute o comando com `--port 8766` e abra essa porta.
- **Chave inválida:** copie a chave da janela da instalação que está executando; não use chaves de outro ZIP.
- **Falha ao baixar pacotes:** confirme internet e tente novamente. O iniciador reaproveita o ambiente.
- **IA indisponível:** o SAST continua funcionando; ative Ollama e baixe exatamente o modelo de `.env`.

Não compartilhe a chave, o arquivo `.env` ou banco de análises. Evidência de uso no Windows e execução distribuída precisa ser coletada no computador correspondente; não foi simulada como validação real.

---

# Abrir o Sentinel no Windows

## Iniciador automatico (recomendado)

1. Extraia o ZIP inteiro; nao execute de dentro do arquivo compactado.
2. Abra a pasta `sentinel-sast` e de dois cliques em **INICIAR_SENTINEL.bat**.
3. Aguarde. Ele gera a configuracao, inicia com Docker se disponivel ou instala as dependencias no modo local, e verifica os dois Security Gates.
4. O navegador sera aberto e a chave de login aparecera na janela do iniciador. Copie-a para entrar. No modo local, deixe essa janela aberta.

E necessario ter Python 3.12 instalado; para a arquitetura distribuida, Docker Desktop instalado e aberto. O iniciador nao instala programas de sistema nem solicita permissao de administrador. A primeira execucao baixa pacotes/imagens.

- **INICIAR_COM_DOCKER.bat**: exige Docker; nao usa a alternativa local.
- **ATIVAR_IA.bat**: inicia o perfil Ollama e baixa o modelo; requer Docker e alguns GB de disco.
- **VERIFICAR_INSTALACAO.bat**: testa API e gates; nao imprime a chave nem abre o navegador.

A verificacao cria duas analises identificadas no historico. O modo Docker fica ligado em segundo plano; o modo local e encerrado ao parar o iniciador.

Os arquivos batch foram preparados para Windows. O bootstrap Python e o modo local foram validados em Linux; a execucao no Windows, Docker e Ollama precisa ocorrer na sua maquina.

---

A seguir, os comandos manuais equivalentes:

## 1. Extraia o ZIP

Extraia o arquivo inteiro para uma pasta simples, por exemplo `C:\Projetos`. Abra no VS Code a pasta `sentinel-sast` que contém `compose.yaml` e `README.md`.

No terminal PowerShell, execute `Get-ChildItem`. Você deve ver esses arquivos. Se aparecer outra pasta `sentinel-sast`, entre nela com `cd sentinel-sast` antes de continuar.

## 2. Gere a configuração

Com Python 3.12 instalado:

```powershell
py -3.12 scripts/setup.py
```

Se seu computador usa `python` no lugar de `py`, use `python scripts/setup.py`. O arquivo `.env` será criado. Abra-o no VS Code e guarde o valor de `API_TOKEN` para o login. As chaves são exclusivas da sua instalação.

## 3. Inicie pelo Docker

Abra o Docker Desktop e aguarde ele ficar pronto. No terminal, dentro da pasta do projeto:

```powershell
docker compose up --build -d
docker compose ps
```

A primeira execução baixa dependências e pode demorar alguns minutos. Abra `http://localhost:8000` no navegador, informe o valor de `API_TOKEN` e entre.

Para testar imediatamente, clique **Experimentar laboratório**. O conjunto vulnerável deve produzir 14 achados em quatro linguagens.

## 4. Habilite o modelo local

```powershell
docker compose --profile ai up -d
docker compose exec ollama ollama pull llama3.2:3b
```

Espere o download terminar. Em **Nova análise**, marque **Revisar com IA local**. Abra um dos três primeiros achados para ver a resposta. A análise poderá levar mais tempo em CPU.

Se usar outro modelo, altere `OLLAMA_MODEL` no `.env`, baixe esse mesmo modelo e recrie o worker com `docker compose up -d worker`.

## 5. Verifique a integração

```powershell
py -3.12 scripts/smoke_compose.py
```

Resultado esperado: gates bloqueado/aprovado nas quatro linguagens e `PASS: API → Redis → Celery → PostgreSQL → relatórios`.

Para parar sem apagar seus resultados:

```powershell
docker compose --profile ai stop
```

## Alternativa sem Docker

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe scripts/setup.py
.\.venv\Scripts\python.exe scripts/run_local.py
```

Deixe esse terminal aberto e acesse `http://localhost:8000`. Não é necessário ativar a venv, evitando problemas de ExecutionPolicy. Essa alternativa permite desenvolver/demonstrar o motor, mas não comprova a arquitetura distribuída exigida pelo trabalho.

## Problemas comuns

| Sintoma | Como resolver |
|---|---|
| `requirements.txt` não encontrado | Entre na pasta onde estão `README.md` e `compose.yaml` |
| `docker` não reconhecido | Instale/abra o Docker Desktop e reabra o terminal |
| Porta 8000 ocupada | Pare a outra aplicação ou troque a porta publicada no Compose para `127.0.0.1:8001:8000`; abra localhost:8001 |
| Login inválido | Cole somente o valor à direita de `API_TOKEN=`; a chave do banco é outra |
| Análise fica na fila | Rode `docker compose logs --tail=80 worker redis api` e verifique os serviços |
| IA indisponível | Verifique `docker compose exec ollama ollama list` e o modelo configurado |
| Nenhum resultado para um ZIP | Envie código-fonte UTF-8, sem dependências; confira linguagens e limites |
| Erro no parser | Corrija a sintaxe no arquivo; o gate bloqueia análises incompletas |

Não compartilhe `.env`. O ZIP entregue não contém credenciais de execução.
