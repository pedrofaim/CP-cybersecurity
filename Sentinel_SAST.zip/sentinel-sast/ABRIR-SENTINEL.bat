@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Sentinel SAST
color 0B

echo.
echo  ============================================
echo    SENTINEL SAST - inicializando...
echo  ============================================
echo.

rem ---- 1) Encontrar um Python adequado (3.11, 3.12 ou 3.13) ----
set "PYEXE="
py -3.12 -c "import sys" >nul 2>&1 && set "PYEXE=py -3.12"
if not defined PYEXE (
  py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1 && set "PYEXE=py -3"
)
if not defined PYEXE (
  python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
  echo [!] Python 3.11, 3.12 ou 3.13 nao encontrado.
  echo     Abrindo a pagina oficial de download...
  start "" https://www.python.org/downloads/windows/
  echo     Instale marcando "Add python.exe to PATH" e execute este arquivo de novo.
  echo.
  pause
  goto :eof
)

rem ---- 2) Iniciar: instala na primeira vez, abre o painel no navegador ----
%PYEXE% scripts\start_windows.py --mode local --port 8765
set "STARTCODE=%ERRORLEVEL%"
if not "%STARTCODE%"=="0" (
  echo.
  echo [!] Algo falhou acima. Se foi porta ocupada, feche outras janelas do Sentinel e tente de novo.
  pause
  goto :eof
)

rem ---- 3) Copiar a chave de acesso para a area de transferencia ----
if exist .env for /f "tokens=1,* delims==" %%a in ('findstr /b API_TOKEN= .env') do set "TOKEN=%%b"
if defined TOKEN (
  echo %TOKEN%| clip
  echo.
  echo  [OK] Chave de acesso COPIADA. Use Ctrl+V no login do painel.
)

echo.
echo  Painel: http://localhost:8765
echo  Deixe esta janela ABERTA enquanto usa o painel. Feche-a para parar.
echo.
pause
