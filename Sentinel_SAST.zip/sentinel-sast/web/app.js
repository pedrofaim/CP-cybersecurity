"use strict";
const $ = (s) => document.querySelector(s),
  $$ = (s) => [...document.querySelectorAll(s)];
const names = {
    critical: "Crítico",
    high: "Alto",
    medium: "Médio",
    low: "Baixo",
  },
  colors = {
    critical: "#ff7385",
    high: "#ffad73",
    medium: "#efcd67",
    low: "#8cb9ed",
  };
const state = {
  scans: [],
  scan: null,
  view: "overview",
  mode: "paste",
  config: null,
  filter: "",
  severity: "",
  language: "",
};
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const fmt = (s) =>
  new Date(
    s.endsWith("Z") || /[+-]\d\d:\d\d$/.test(s) ? s : s + "Z",
  ).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
const pill = (key, label) =>
  `<span class="pill ${esc(key)}">${esc(label || names[key] || key)}</span>`;
function toast(s) {
  $("#toast").textContent = s;
  $("#toast").hidden = false;
  setTimeout(() => ($("#toast").hidden = true), 4500);
}
async function api(path, opts = {}) {
  const r = await fetch("/api" + path, {
    ...opts,
    headers:
      opts.body instanceof FormData
        ? {}
        : { "Content-Type": "application/json", ...opts.headers },
  });
  if (r.status === 401) {
    if (!$("#login-dialog").open) $("#login-dialog").showModal();
    throw Error("Faça login para continuar.");
  }
  if (!r.ok) {
    const e = await r.json().catch(() => ({ detail: "Erro de comunicação" }));
    throw Error(
      typeof e.detail === "string"
        ? e.detail
        : "Confira os arquivos e os limites de envio.",
    );
  }
  return r.json();
}
async function refresh(id) {
  state.scans = await api("/scans");
  $("#scan-select").innerHTML = state.scans.length
    ? state.scans
        .map(
          (s) =>
            `<option value="${s.id}">${esc(s.name)} · ${fmt(s.created_at)}</option>`,
        )
        .join("")
    : '<option value="">Nenhuma análise</option>';
  const chosen = id || state.scan?.id || state.scans[0]?.id;
  if (chosen && state.scans.some((s) => s.id === chosen)) {
    state.scan = await api("/scans/" + chosen);
    $("#scan-select").value = chosen;
  } else state.scan = null;
  render();
  if (state.scan && ["queued", "running"].includes(state.scan.status))
    setTimeout(
      () => refresh(state.scan?.id).catch((e) => toast(e.message)),
      1500,
    );
}
async function initialize() {
  try {
    state.config = await api("/config");
    await refresh();
  } catch (e) {
    if (!$("#login-dialog").open) toast(e.message);
  }
}
function setView(view) {
  state.view = view;
  const titles = {
    overview: [
      "Visão geral",
      "Resultados da análise estática e prioridades de correção.",
    ],
    findings: [
      "Vulnerabilidades",
      "Evidências, impacto e orientação para cada achado.",
    ],
    history: [
      "Histórico de análises",
      "Acompanhe suas varreduras e compare a evolução do projeto.",
    ],
    rules: [
      "Regras e cobertura",
      "Saiba o que o motor detecta e onde a revisão humana é necessária.",
    ],
    pipeline: [
      "DevSecOps",
      "Políticas de bloqueio e integração com o pipeline.",
    ],
  };
  $("#page-title").textContent = titles[view][0];
  $("#breadcrumb").textContent = titles[view][0];
  $("#page-subtitle").textContent = titles[view][1];
  $$(".nav").forEach((n) =>
    n.classList.toggle("active", n.dataset.view === view),
  );
  $$(".view").forEach((v) => (v.hidden = v.id !== "view-" + view));
  render();
}
function render() {
  const s = state.scan,
    r = s?.result;
  $("#demo-label").hidden = !s?.demo;
  $("#scan-date").textContent = s
    ? fmt(s.created_at) +
      " · " +
      (r
        ? r.summary.files_analyzed + " arquivos analisados"
        : { queued: "Na fila", running: "Analisando…", failed: "Falhou" }[
            s.status
          ] || "")
    : "Aguardando primeira varredura";
  $("#nav-count").textContent = r?.summary.total || 0;
  $("#export").disabled = !r;
  const banner = $("#status-banner");
  banner.hidden = true;
  if (s && s.status !== "completed") {
    banner.hidden = false;
    banner.className =
      "info-banner" + (s.status === "failed" ? " error-banner" : "");
    banner.textContent =
      s.status === "failed"
        ? s.error
        : "◌ Análise em andamento. Esta tela será atualizada automaticamente.";
  } else if (r?.summary.parse_errors) {
    banner.hidden = false;
    banner.className = "info-banner error-banner";
    banner.textContent = `${r.summary.parse_errors} arquivo(s) com erro de sintaxe. O Security Gate está bloqueado; consulte os detalhes abaixo.`;
  } else if (s?.demo) {
    banner.hidden = false;
    banner.className = "info-banner";
    banner.textContent =
      "Laboratório de demonstração: os achados abaixo foram calculados pelo motor a partir de exemplos intencionalmente vulneráveis.";
  }
  if (state.view === "overview") renderOverview();
  if (state.view === "findings") renderFindings();
  if (state.view === "history") renderHistory();
  if (state.view === "rules") renderRules();
  if (state.view === "pipeline") renderPipeline();
  wireDynamic();
}
function empty() {
  return `<div class="panel empty"><div class="empty-symbol"><svg class="svg-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5M7 9l3 3-3 3m6 0h4"/></svg></div><div class="eyebrow">NENHUMA ANÁLISE REGISTRADA</div><h2>Comece por um arquivo ou projeto.</h2><p>Analise Python, JavaScript, TypeScript e Java. Descubra vulnerabilidades e o caminho para corrigi-las.</p><div class="empty-actions"><button class="button primary" data-action="new">＋ Analisar meu código</button><button class="button secondary" data-action="demo">Experimentar laboratório →</button></div></div>`;
}
function metric(label, value, foot, icon, cls = "", extra = "") {
  return `<div class="metric ${cls}"><div class="metric-top">${label}<span class="metric-icon">${icon}</span></div><div class="metric-number">${value}</div>${extra}<div class="metric-bottom">${foot}</div></div>`;
}
function renderOverview() {
  const s = state.scan,
    r = s?.result;
  if (!r) {
    $("#view-overview").innerHTML = empty();
    return;
  }
  const m = r.summary,
    c = m.counts;
  const criticalFiles = Object.create(null);
  const weights = { critical: 30, high: 15, medium: 5, low: 1 };
  r.findings.forEach((f) => {
    if (!criticalFiles[f.file]) criticalFiles[f.file] = { count: 0, weight: 0 };
    criticalFiles[f.file].count += 1;
    criticalFiles[f.file].weight += weights[f.severity];
  });
  const files = Object.entries(criticalFiles)
    .sort((a, b) => b[1].weight - a[1].weight)
    .slice(0, 5);
  const score = m.risk_score;
  const risk =
    score >= 70
      ? "Exposição elevada"
      : score >= 30
        ? "Requer atenção"
        : score > 0
          ? "Baixa exposição detectada"
          : "Nenhum risco detectado";
  $("#view-overview").innerHTML =
    `<div class="cards">${metric("Índice de risco", score + "<small>/ 100</small>", risk, "◈", "", `<div class="riskline"><span style="width:${score}%;background:${score >= 70 ? colors.critical : score >= 30 ? colors.medium : "#45a68c"}"></span></div>`)}${metric("Vulnerabilidades", m.total, `${m.files_analyzed} arquivos · ${m.languages.length} linguagens`, "◇")}${metric("Riscos críticos", c.critical, `${c.high} de severidade alta`, "!", "critical")}${metric("Security Gate", m.gate === "blocked" ? "Bloqueado" : "Aprovado", m.gate === "blocked" ? `${m.blocking_findings} achados bloqueantes · ${m.parse_errors} erros` : "Dentro da política configurada", m.gate === "blocked" ? "⊘" : "✓", "gate " + m.gate)}</div><div class="grid-charts"><div class="panel"><div class="panel-head"><div><h3 class="panel-title">Evolução das vulnerabilidades</h3><p class="panel-subtitle">Últimas análises deste projeto</p></div><div class="chart-legend"><span><i style="background:#f0b568"></i>Total</span><span><i style="background:#ff7385"></i>Críticas</span></div></div><div class="trend">${trend()}</div></div><div class="panel"><div class="panel-head"><div><h3 class="panel-title">Distribuição por severidade</h3><p class="panel-subtitle">Achados na análise selecionada</p></div></div>${donut(c, m.total)}</div></div><div class="lower-grid"><div class="panel"><div class="panel-head"><div><h3 class="panel-title">Arquivos prioritários</h3><p class="panel-subtitle">Top 5 · prioridade ponderada por severidade</p></div><span class="muted">↗</span></div><div class="file-bars">${files.length ? files.map(([f, n]) => `<div class="file-row"><div class="file-label"><code>${esc(f)}</code><span>${n.count} ${n.count === 1 ? "achado" : "achados"} · ${n.weight} pts</span></div><div class="bar-track"><i style="width:${(n.weight / files[0][1].weight) * 100}%"></i></div></div>`).join("") : '<p class="muted">Nenhum achado nos arquivos analisados.</p>'}</div></div><div class="panel gate-panel ${m.gate}"><div class="gate-heading"><span class="gate-symbol">${m.gate === "blocked" ? "⊘" : "✓"}</span><div><h3>Política de segurança</h3>${pill(m.gate, m.gate === "blocked" ? "Gate bloqueado" : "Gate aprovado")}</div></div><p>${m.gate === "blocked" ? "Resolva os achados bloqueantes antes de integrar a mudança." : "Nenhum achado bloqueante nesta análise. Mantenha a revisão de código."}</p><div class="gate-rule"><span>Severidade mínima</span><b>${names[m.gate_threshold]}</b></div><div class="gate-rule"><span>Erros de parsing</span><b>Sempre bloqueiam</b></div><button class="link-button" data-view="pipeline">Ver integração com CI/CD →</button></div></div>${findingsTable(r.findings.slice(0, 5), false)}<div class="form-hint">Índice heurístico = mínimo de 100 e (30 × críticos + 15 × altos + 5 × médios + baixos). Não é CVSS nem probabilidade de ataque.</div>${fileWarnings(r)}`;
}
function trend() {
  const a = state.scans
    .map((x) =>
      x.id === state.scan.id && state.scan.result
        ? {
            ...x,
            status: state.scan.status,
            summary: state.scan.result.summary,
          }
        : x,
    )
    .filter(
      (x) =>
        x.status === "completed" &&
        x.name === state.scan.name &&
        x.demo === state.scan.demo,
    )
    .slice(0, 8)
    .reverse();
  const max = Math.max(5, ...a.map((x) => x.summary.total));
  const x = (i) => (a.length === 1 ? 270 : 45 + (i * 445) / (a.length - 1)),
    y = (v) => 137 - (v / max) * 108;
  const pts = (field) =>
    a
      .map(
        (s, i) =>
          `${x(i)},${y(field === "total" ? s.summary.total : s.summary.counts.critical)}`,
      )
      .join(" ");
  return `<svg viewBox="0 0 530 174" role="img" aria-label="Tendência das análises registradas"><defs><linearGradient id="area" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#f0b568" stop-opacity=".2"/><stop offset="100%" stop-color="#f0b568" stop-opacity="0"/></linearGradient></defs>${[
    0, 1, 2, 3,
  ]
    .map((i) => {
      const v = Math.round((max * i) / 3),
        yy = y(v);
      return `<line x1="35" x2="504" y1="${yy}" y2="${yy}" stroke="#2b3542" stroke-dasharray="3 4"/><text x="8" y="${yy + 3}" fill="#95a9c0" font-size="10">${v}</text>`;
    })
    .join(
      "",
    )}${a.length > 1 ? `<polygon points="${x(0)},137 ${pts("total")} ${x(a.length - 1)},137" fill="url(#area)"/><polyline points="${pts("total")}" stroke="#f0b568" stroke-width="2.5" fill="none"/><polyline points="${pts("critical")}" stroke="#ff7385" stroke-width="2" fill="none"/>` : ""}${a.map((s, i) => `<circle cx="${x(i)}" cy="${y(s.summary.total)}" r="4" fill="#f0b568" stroke="#141a22" stroke-width="2"/><circle cx="${x(i)}" cy="${y(s.summary.counts.critical)}" r="3" fill="#ff7385"/><text x="${x(i)}" y="160" text-anchor="middle" fill="#9db0c7" font-size="10">${i + 1} · ${fmt(s.created_at).split(",")[0]}</text>`).join("")}${a.length === 1 ? '<text x="270" y="16" text-anchor="middle" fill="#9db0c7" font-size="10">A tendência será formada nas próximas análises</text>' : ""}</svg>`;
}
function donut(c, total) {
  let acc = 0;
  const segments = Object.keys(names)
    .map((k) => {
      const start = acc;
      acc += total ? (c[k] / total) * 100 : 0;
      return `${colors[k]} ${start}% ${acc}%`;
    })
    .join(",");
  return `<div class="donut-wrap"><div class="donut" style="background:${total ? "conic-gradient(" + segments + ")" : "#2a3543"}"><div class="donut-center">${total}<small>achados</small></div></div><div class="severity-legend">${Object.keys(
    names,
  )
    .map(
      (k) =>
        `<div><span><i style="background:${colors[k]}"></i>${names[k]}</span><b>${c[k]}</b></div>`,
    )
    .join("")}</div></div>`;
}
function findingsTable(findings, filters) {
  return `<div class="panel table-panel"><div class="table-toolbar"><div><h3>${filters ? "Todos os achados" : "Achados prioritários"} <span class="muted">${findings.length} ${filters ? "resultados" : "em destaque"}</span></h3></div>${
    filters
      ? `<div class="filters"><input id="search-findings" aria-label="Buscar vulnerabilidades" placeholder="Buscar arquivo, regra, CWE…" value="${esc(state.filter)}"><select id="severity-filter" aria-label="Filtrar severidade"><option value="">Todas as severidades</option>${Object.keys(
          names,
        )
          .map(
            (k) =>
              `<option value="${k}" ${state.severity === k ? "selected" : ""}>${names[k]}</option>`,
          )
          .join(
            "",
          )}</select><select id="language-filter" aria-label="Filtrar linguagem"><option value="">Todas as linguagens</option>${(state.config?.languages || []).map((k) => `<option ${state.language === k ? "selected" : ""}>${k}</option>`).join("")}</select></div>`
      : '<button class="link-button" data-view="findings">Ver todas →</button>'
  }</div><div class="table-wrap"><table><thead><tr><th>VULNERABILIDADE</th><th>SEVERIDADE</th><th>ARQUIVO / LINHA</th><th>LINGUAGEM</th><th></th></tr></thead><tbody>${findings.length ? findings.map((f) => `<tr class="clickable" data-finding="${f.id}" tabindex="0" role="button" aria-label="Abrir ${esc(f.title)}"><td><span class="finding-title">${esc(f.title)}</span><span class="finding-sub">${f.cwe} &nbsp;·&nbsp; ${f.rule_id}${f.flow.length ? " &nbsp;·&nbsp; fluxo rastreado" : ""}</span></td><td>${pill(f.severity)}</td><td><code>${esc(f.file)}</code><span class="finding-sub">Linha ${f.line}</span></td><td>${esc(f.language)}</td><td><span class="open-finding">↗</span></td></tr>`).join("") : '<tr><td colspan="5" class="empty">Nenhum achado corresponde a esta seleção.</td></tr>'}</tbody></table></div><div class="table-bottom"><span>Resultados do motor estático</span><span>Clique em um achado para investigar →</span></div></div>`;
}
function fileWarnings(r) {
  const skipped = r.files.filter((f) => f.status !== "analyzed");
  return skipped.length
    ? `<div class="panel coverage"><h3>Arquivos que exigem atenção</h3>${skipped.map((f) => `<p><code>${esc(f.file)}</code> — ${esc(f.message || "Extensão não suportada; arquivo ignorado.")}</p>`).join("")}</div>`
    : "";
}
function renderFindings() {
  const r = state.scan?.result;
  if (!r) {
    $("#view-findings").innerHTML = empty();
    return;
  }
  const filtered = r.findings.filter(
    (f) =>
      (!state.severity || f.severity === state.severity) &&
      (!state.language || f.language === state.language) &&
      (!state.filter ||
        [f.title, f.file, f.cwe, f.rule_id]
          .join(" ")
          .toLowerCase()
          .includes(state.filter.toLowerCase())),
  );
  $("#view-findings").innerHTML =
    findingsTable(filtered, true) + fileWarnings(r);
}
function renderHistory() {
  $("#view-history").innerHTML = state.scans.length
    ? `<div class="panel table-panel"><div class="table-toolbar"><h3>Análises registradas</h3><button class="link-button" data-action="demo">Executar laboratório →</button></div><div class="table-wrap"><table><thead><tr><th>PROJETO</th><th>EXECUÇÃO</th><th>ACHADOS</th><th>GATE</th><th>AÇÕES</th></tr></thead><tbody>${state.scans.map((s) => `<tr><td><span class="history-name">${esc(s.name)}</span><span class="finding-sub">${s.demo ? "Demonstração · " : ""}${fmt(s.created_at)}</span></td><td>${{ completed: "Concluída", running: "Em andamento", queued: "Na fila", failed: "Falhou" }[s.status]}</td><td>${s.summary?.total ?? "—"}</td><td>${s.summary ? pill(s.summary.gate, s.summary.gate === "blocked" ? "Bloqueado" : "Aprovado") : "—"}</td><td><button class="link-button" data-open-scan="${s.id}">Abrir</button> &nbsp; ${["completed", "failed"].includes(s.status) ? `<button class="link-button" data-delete-scan="${s.id}">Excluir</button>` : ""}</td></tr>`).join("")}</tbody></table></div></div>`
    : empty();
}
function renderRules() {
  $("#view-rules").innerHTML =
    `<div class="panel coverage"><h3>Linguagens e limites da análise</h3><p><b>Python:</b> AST nativa, aliases de imports e propagação de variáveis. <b>JavaScript, TypeScript e Java:</b> Tree-sitter com regras estruturais e rastreamento intraprocedural de padrões reconhecidos.</p><p>Não há análise interprocedural, resolução completa de tipos ou prova formal de ausência de falhas. Branches são unidos de forma conservadora. Sanitização HTML/SQL genérica não é presumida; apenas conversões numéricas reconhecidas interrompem os fluxos atuais. Java possui cobertura menor: SQL, comandos com entrada rastreada, credenciais, hash fraco, desserialização, caminhos de arquivo e URLs em padrões reconhecidos. Consulte docs/COBERTURA.md.</p></div><div class="rule-grid">${Object.entries(
      state.config?.rules || {},
    )
      .map(
        ([id, r]) =>
          `<div class="panel rule-card"><div class="rule-meta"><span>${id} · ${r.cwe}</span>${pill(r.severity)}</div><h3>${esc(r.title)}</h3><p>${esc(r.description)}</p><div class="form-hint">${r.owasp} · referência OWASP 2021</div></div>`,
      )
      .join(
        "",
      )}</div><div class="info-banner">CWE identifica a classe da falha. Um achado no seu código não é automaticamente um CVE. A classificação pode exigir confirmação humana.</div>`;
}
function renderPipeline() {
  $("#view-pipeline").innerHTML =
    `<div class="pipeline-grid"><div class="panel doc-card"><div class="eyebrow">SECURITY GATE</div><h3>Política de aprovação</h3><p>O CLI retorna um código de saída que o GitHub Actions usa para bloquear mudanças com riscos acima do limite.</p><pre class="code">python -m sentinel.cli src \\\n  --threshold high \\\n  --output report.json \\\n  --sarif report.sarif</pre><div class="gate-rule"><span>0 · Aprovado</span><b>Sem achados bloqueantes</b></div><div class="gate-rule"><span>1 · Bloqueado</span><b>Achados, parsing ou nenhum arquivo</b></div><div class="gate-rule"><span>2 · Erro operacional</span><b>Análise não concluída</b></div></div><div class="panel doc-card"><div class="eyebrow">PIPELINE INCLUÍDO</div><h3>Etapas da verificação</h3><ol><li>Instala dependências fixadas no projeto.</li><li>Executa os testes do motor e da API.</li><li>Analisa o código da plataforma com Bandit e Sentinel.</li><li>Valida exemplos vulneráveis e seguros.</li><li>Publica relatórios JSON/SARIF como artefatos.</li></ol><p>Configure a proteção da branch para exigir os jobs <b>security</b> e <b>containers</b>. O YAML sozinho não impede merges manuais.</p></div><div class="panel doc-card"><div class="eyebrow">ARQUITETURA</div><h3>Processamento assíncrono</h3><p>A API recebe a análise e retorna um identificador. Redis transporta a tarefa; workers Celery executam o parsing e gravam o resultado no PostgreSQL. Ollama fornece revisão semântica opcional.</p><p>Modo atual: <b>${esc(state.config?.queue || "local")}</b>. O modo local usa uma fila em memória e SQLite para desenvolvimento; Docker Compose ativa Celery e PostgreSQL.</p></div><div class="panel doc-card"><div class="eyebrow">IA COM CONTROLE</div><h3>Revisão semântica local</h3><p>O modelo ${esc(state.config?.ai_model || "llama3.2:3b")} recebe o achado e um trecho com credenciais literais mascaradas. Pode sugerir severidade, falso positivo e código corrigido.</p><p>A IA não executa código, não aplica correções e não rebaixa o gate automaticamente. Se estiver indisponível, a interface informa o estado sem inventar uma resposta.</p><button class="button secondary" id="check-ai">Verificar Ollama</button><p id="ai-status" role="status" class="form-hint">Consulte a disponibilidade do modelo nesta instalação.</p></div></div>`;
}
function openFinding(id) {
  const f = state.scan.result.findings.find((f) => f.id === id);
  if (!f) return;
  $("#finding-content").innerHTML =
    `<div class="modal-head"><div><div class="eyebrow">INVESTIGAR ACHADO · ${f.rule_id}</div><h2>${esc(f.title)}</h2></div><button class="icon-button" data-close="finding-dialog" aria-label="Fechar">×</button></div><div class="finding-meta">${pill(f.severity)}${pill("neutral", f.cwe)}${pill("neutral", f.language)}${pill("neutral", "Confiança " + (f.confidence === "high" ? "alta" : "moderada"))}</div><div class="finding-body"><p><b>${esc(f.file)} : ${f.line}</b> · ${esc(f.engine)}</p><h3>O que está acontecendo</h3><p>${esc(f.description)}</p><h3>Evidência no código</h3><pre class="code evidence-code">${f.snippet
      .split("\n")
      .map(
        (line) =>
          `<span class="code-line ${parseInt(line, 10) === f.line ? "highlight" : ""}">${esc(line)}</span>`,
      )
      .join(
        "",
      )}</pre><h3>Fluxo de dados</h3>${f.flow.length ? `<div class="flow">${f.flow.map((x) => `<div class="flow-step ${esc(x.kind)}">${esc(x.label)}<small>Linha ${x.line} · ${x.kind === "source" ? "origem" : x.kind === "sink" ? "destino" : "propagação"}</small></div>`).join('<span class="muted">→</span>')}</div>` : "<p>Regra estrutural. Não há fluxo de entrada externa comprovado para este achado.</p>"}<h3>Como corrigir</h3><div class="remediation"><p>${esc(f.remediation)}</p></div><h3>Revisão semântica · IA local</h3><div class="ai-box">${f.ai?.status === "complete" ? `<p>${pill(f.ai.severity, "Severidade sugerida: " + names[f.ai.severity])} ${f.ai.possible_false_positive ? "Possível falso positivo · confirme manualmente" : ""}</p><p>${esc(f.ai.explanation)}</p><p>${esc(f.ai.remediation)}</p><pre class="code">${esc(f.ai.corrected_code)}</pre><p class="form-hint">${esc(f.ai.model)} · sugestão não testada, sujeita à revisão. O gate mantém a severidade determinística.</p>` : `<p>${esc(f.ai?.explanation || "Revisão por IA não solicitada. Ative “Revisar com IA local” em uma nova análise com o Ollama disponível.")}</p>`}</div><p class="form-hint">${f.owasp} · mapeamento de referência. A análise estática aponta riscos potenciais; valide a explorabilidade no contexto autorizado.</p></div>`;
  wireDynamic();
  $("#finding-dialog").showModal();
}
function wireDynamic() {
  if ($("#check-ai"))
    $("#check-ai").onclick = async () => {
      const button = $("#check-ai");
      button.disabled = true;
      $("#ai-status").textContent = "Consultando o serviço local…";
      try {
        const status = await api("/ai/status");
        const messages = {
          installed:
            "Modelo instalado. A inferência será solicitada na próxima análise com IA.",
          missing_model:
            "Ollama responde, mas o modelo precisa ser baixado. Use ATIVAR_IA.bat.",
          unavailable:
            "Ollama indisponível. Use ATIVAR_IA.bat com o Docker Desktop aberto.",
        };
        $("#ai-status").textContent =
          status.model + " · " + messages[status.status];
      } catch (error) {
        $("#ai-status").textContent = error.message;
      } finally {
        button.disabled = false;
      }
    };

  document
    .querySelectorAll("[data-view]")
    .forEach((n) => (n.onclick = () => setView(n.dataset.view)));
  $$('[data-action="new"]').forEach(
    (n) => (n.onclick = () => $("#scan-dialog").showModal()),
  );
  $$('[data-action="demo"]').forEach(
    (n) =>
      (n.onclick = async () => {
        n.disabled = true;
        try {
          const s = await api("/scans/demo", { method: "POST" });
          await refresh(s.id);
        } catch (e) {
          toast(e.message);
        } finally {
          n.disabled = false;
        }
      }),
  );
  $$("[data-finding]").forEach((n) => {
    n.onclick = () => openFinding(n.dataset.finding);
    n.onkeydown = (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        openFinding(n.dataset.finding);
      }
    };
  });
  $$("[data-close]").forEach(
    (n) => (n.onclick = () => $("#" + n.dataset.close).close()),
  );
  $$("[data-open-scan]").forEach(
    (n) =>
      (n.onclick = async () => {
        await refresh(n.dataset.openScan);
        setView("overview");
      }),
  );
  $$("[data-delete-scan]").forEach(
    (n) =>
      (n.onclick = async () => {
        if (!confirm("Excluir esta análise e seus resultados?")) return;
        try {
          await api("/scans/" + n.dataset.deleteScan, { method: "DELETE" });
          if (state.scan?.id === n.dataset.deleteScan) state.scan = null;
          await refresh();
          toast("Análise excluída.");
        } catch (e) {
          toast(e.message);
        }
      }),
  );
  if ($("#search-findings"))
    $("#search-findings").oninput = (e) => {
      const pos = e.target.selectionStart;
      state.filter = e.target.value;
      renderFindings();
      wireDynamic();
      $("#search-findings").focus();
      $("#search-findings").setSelectionRange(pos, pos);
    };
  if ($("#severity-filter"))
    $("#severity-filter").onchange = (e) => {
      state.severity = e.target.value;
      renderFindings();
      wireDynamic();
    };
  if ($("#language-filter"))
    $("#language-filter").onchange = (e) => {
      state.language = e.target.value;
      renderFindings();
      wireDynamic();
    };
}
$("#login-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    await api("/session", {
      method: "POST",
      body: JSON.stringify({ token: $("#token").value }),
    });
    $("#token").value = "";
    $("#login-error").textContent = "";
    $("#login-dialog").close();
    await initialize();
  } catch (e) {
    $("#login-error").textContent = e.message;
  }
};
$("#login-dialog").addEventListener("cancel", (e) => e.preventDefault());
$("#new-scan").onclick = () => $("#scan-dialog").showModal();
$("#scan-select").onchange = (e) =>
  refresh(e.target.value).catch((e) => toast(e.message));
$("#export").onclick = () => $("#export-dialog").showModal();
$$("[data-download]").forEach(
  (n) =>
    (n.onclick = () => {
      location.href =
        "/api/scans/" + state.scan.id + "/export?format=" + n.dataset.download;
      $("#export-dialog").close();
    }),
);
$("#logout").onclick = async () => {
  await api("/session", { method: "DELETE" });
  location.reload();
};
$$("[data-mode]").forEach(
  (n) =>
    (n.onclick = () => {
      state.mode = n.dataset.mode;
      $$("[data-mode]").forEach((b) => b.classList.toggle("active", b === n));
      $("#paste-pane").hidden = state.mode !== "paste";
      $("#upload-pane").hidden = state.mode !== "upload";
      $("#file-name").required = state.mode === "paste";
    }),
);
const samples = {
  py: [
    "app.py",
    'from flask import request\nimport os\n\ndef search(db):\n    name = request.args.get("name")\n    query = "SELECT * FROM users WHERE name = \'" + name + "\'"\n    db.execute(query)\n    os.system(request.args.get("command"))\n',
  ],
  js: [
    "routes.js",
    'function search(req, res, db) {\n  const name = req.query.name;\n  const query = "SELECT * FROM users WHERE name = \'" + name + "\'";\n  db.query(query);\n  eval(req.body.code);\n}\n',
  ],
  ts: [
    "profile.ts",
    "function profile(req: any, element: HTMLElement) {\n  const name: string = req.query.name;\n  element.innerHTML = name;\n  fetch(req.query.url);\n}\n",
  ],
  java: [
    "Search.java",
    'class Search {\n  void search(HttpServletRequest request, Statement stmt) throws Exception {\n    String name = request.getParameter("name");\n    String sql = "SELECT * FROM users WHERE name = \'" + name + "\'";\n    stmt.executeQuery(sql);\n  }\n}\n',
  ],
};
$("#sample").onchange = (e) => {
  const s = samples[e.target.value];
  if (s) {
    $("#file-name").value = s[0];
    $("#source-code").value = s[1];
  }
};
$("#scan-form").onsubmit = async (e) => {
  e.preventDefault();
  $("#scan-error").textContent = "";
  const btn = $("#submit-scan");
  btn.disabled = true;
  btn.textContent = "Enviando…";
  try {
    let result;
    const name = $("#project-name").value,
      threshold = $("#threshold").value,
      use_ai = $("#use-ai").checked;
    if (state.mode === "upload") {
      const files = [...$("#source-files").files];
      if (!files.length) throw Error("Selecione os arquivos.");
      if (files.some((f) => f.name.endsWith(".zip"))) {
        if (files.length !== 1) throw Error("Envie um ZIP por vez.");
        const body = new FormData();
        body.append("file", files[0]);
        body.append("name", name);
        body.append("threshold", threshold);
        body.append("use_ai", String(use_ai));
        result = await api("/scans/upload", { method: "POST", body });
      } else {
        if (
          files.length > 100 ||
          files.reduce((a, f) => a + f.size, 0) > 2000000
        )
          throw Error("Limite: 100 arquivos / 2 MB.");
        const source = await Promise.all(
          files.map(async (f) => ({ path: f.name, content: await f.text() })),
        );
        result = await api("/scans", {
          method: "POST",
          body: JSON.stringify({ name, threshold, use_ai, files: source }),
        });
      }
    } else {
      if (!$("#source-code").value.trim())
        throw Error("Cole um código para analisar.");
      result = await api("/scans", {
        method: "POST",
        body: JSON.stringify({
          name,
          threshold,
          use_ai,
          files: [
            { path: $("#file-name").value, content: $("#source-code").value },
          ],
        }),
      });
    }
    $("#scan-dialog").close();
    setView("overview");
    await refresh(result.id);
    toast("Análise enviada. Acompanhe o resultado no painel.");
  } catch (e) {
    $("#scan-error").textContent = e.message;
  } finally {
    btn.disabled = false;
    btn.textContent = "Iniciar análise →";
  }
};
wireDynamic();
initialize();
