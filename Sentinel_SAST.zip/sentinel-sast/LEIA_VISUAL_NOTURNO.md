# Atualização visual do Sentinel — interface 1.1

## Atualizar a instalação que você já está usando

1. Extraia este ZIP para uma pasta temporária.
2. Copie a pasta **web** inteira para dentro da sua pasta **sentinel-sast**, substituindo a pasta web anterior. Inclua a subpasta fonts.
3. Se usa o modo local/Python, atualize o navegador com **Ctrl+F5**. Não é necessário reinstalar pacotes.
4. Se usa Docker, execute **INICIAR_COM_DOCKER.bat** na pasta original do projeto para reconstruir a imagem com a nova interface. Depois pressione Ctrl+F5 no navegador. Também pode usar `docker compose up --build -d`.

O pacote de atualização contém apenas web e este guia. Não substitui `.env`, `sentinel.db`, volumes do Docker ou o backend. Sua chave de acesso e os resultados existentes continuam na instalação original.

## Alterações

- Tema escuro em todas as telas, formulários, tabelas e diálogos.
- IBM Plex Sans para a interface e IBM Plex Mono para números, caminhos e código; arquivos e licenças incluídos, sem carregamento externo.
- Grafite e âmbar na interface; vermelho, laranja, amarelo e azul para severidades, acompanhados de texto.
- Ícones vetoriais consistentes, contraste melhor e navegação por teclado preservada.
- Linha do achado destacada no trecho de código e indicação visual de origem/destino.
- Tabela com rolagem horizontal dentro do painel em telas pequenas.
- Textos mais diretos e técnicos.
- Correção da atualização da tendência: a análise recém-concluída entra no gráfico imediatamente, mesmo quando a listagem de histórico ainda contém o estado anterior.

O motor, as regras, os limites e a integração com IA são os mesmos. O design não comprova autoria nem substitui a compreensão técnica e o atendimento às regras acadêmicas da disciplina.

## Verificação

Interface executada em Chromium headless com API real: 1440 px desktop e 390 px mobile. Foram verificados laboratório com 14 achados, filtro Java, detalhe de SQLi, nova análise segura, gate aprovado, histórico, regras e DevSecOps. Fontes locais carregadas; nenhum erro JavaScript registrado; sem overflow horizontal da página mobile. As capturas foram inspecionadas visualmente.

Docker e inferência real do Ollama continuam dependendo de validação na máquina de execução; esta atualização trata da interface.
