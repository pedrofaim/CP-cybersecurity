from .rules import RULES
from urllib.parse import quote


def sarif(result):
    return {
        "version": "2.1.0",
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "Sentinel SAST",
                        "version": "1.2.0",
                        "rules": [
                            {
                                "id": rid,
                                "name": r["title"],
                                "shortDescription": {"text": r["description"]},
                                "help": {"text": r["remediation"]},
                                "properties": {"tags": ["security", r["cwe"]]},
                            }
                            for rid, r in RULES.items()
                        ],
                    }
                },
                "results": [
                    {
                        "ruleId": f["rule_id"],
                        "level": "error"
                        if f["severity"] in ("critical", "high")
                        else "warning",
                        "message": {"text": f["description"]},
                        "locations": [
                            {
                                "physicalLocation": {
                                    "artifactLocation": {
                                        "uri": quote(f["file"], safe="/._-")
                                    },
                                    "region": {"startLine": f["line"]},
                                }
                            }
                        ],
                        "partialFingerprints": {"sentinel/v1": f["id"]},
                    }
                    for f in result["findings"]
                ],
            }
        ],
    }
