import os
from datetime import datetime, timezone, timedelta
from sqlalchemy import create_engine, String, DateTime, JSON, Text, update
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

URL = os.getenv("DATABASE_URL", "sqlite:///./sentinel.db")
engine = create_engine(
    URL,
    connect_args={"check_same_thread": False} if URL.startswith("sqlite") else {},
    pool_pre_ping=True,
)
Session = sessionmaker(engine, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class Scan(Base):
    __tablename__ = "scans"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    status: Mapped[str] = mapped_column(String(30), default="queued")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    finished_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    payload: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    demo: Mapped[bool] = mapped_column(default=False)


def init_db():
    Base.metadata.create_all(engine)


def expire_scans(restarting_local=False):
    """Fail closed after an interrupted local process or an excessive queue age."""
    now = datetime.now(timezone.utc)
    statement = update(Scan).where(Scan.status.in_(["queued", "running"]))
    if not restarting_local:
        statement = statement.where(Scan.created_at < now - timedelta(minutes=30))
    with Session() as db:
        db.execute(
            statement.values(
                status="failed",
                payload=None,
                finished_at=now,
                error="Análise interrompida ou prazo de 30 minutos excedido. Envie novamente; nenhum gate foi aprovado.",
            )
        )
        db.commit()


def serialize(s, full=False):
    return dict(
        id=s.id,
        name=s.name,
        status=s.status,
        created_at=s.created_at.isoformat(),
        finished_at=s.finished_at.isoformat() if s.finished_at else None,
        demo=s.demo,
        error=s.error,
        **(
            {"result": s.result}
            if full
            else {"summary": s.result["summary"] if s.result else None}
        ),
    )
