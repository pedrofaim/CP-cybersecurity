import hashlib
import hmac
import io
import json
import os
import secrets
import time
import uuid
import zipfile
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal
from fastapi import (
    FastAPI,
    HTTPException,
    Request,
    Response,
    UploadFile,
    File,
    Form,
    Depends,
)
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import select, func
from .storage import Session, Scan, init_db, serialize, expire_scans
from .body_limit import BodyLimitMiddleware
from .jobs import dispatch
from .engine import safe_path, path_language, EXTENSIONS
from .rules import RULES
from .ai import model_status
from .reports import sarif

ROOT = Path(__file__).resolve().parent.parent
TOKEN = os.getenv("API_TOKEN") or secrets.token_urlsafe(32)
MAX_TOTAL = 2_000_000
MAX_FILE = 200_000
attempts = defaultdict(deque)


@asynccontextmanager
async def lifespan(app):
    init_db()
    expire_scans(restarting_local=os.getenv("QUEUE_MODE", "local") == "local")
    if not os.getenv("API_TOKEN"):
        print(
            "Sentinel: API_TOKEN ausente. Configure a variável antes de acessar. Use python scripts/setup.py para gerar .env."
        )
    yield


app = FastAPI(
    title="Sentinel SAST",
    version="1.2.0",
    lifespan=lifespan,
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
)


def session_value():
    stamp = str(int(time.time()))
    return (
        stamp
        + "."
        + hmac.new(TOKEN.encode(), stamp.encode(), hashlib.sha256).hexdigest()
    )


def authorized(request):
    bearer = request.headers.get("authorization", "")
    if bearer.startswith("Bearer ") and hmac.compare_digest(
        bearer[7:].encode(), TOKEN.encode()
    ):
        return True
    cookie = request.cookies.get("sentinel_session", "")
    try:
        stamp, sig = cookie.split(".")
        return 0 <= time.time() - int(stamp) < 28800 and hmac.compare_digest(
            sig, hmac.new(TOKEN.encode(), stamp.encode(), hashlib.sha256).hexdigest()
        )
    except (ValueError, TypeError):
        return False


def auth(request: Request):
    if not authorized(request):
        raise HTTPException(401, "Entre com a chave de acesso da instalação.")


@app.middleware("http")
async def security(request, call_next):
    if request.method in ("POST", "DELETE", "PUT", "PATCH"):
        origin = request.headers.get("origin")
        expected = str(request.base_url).rstrip("/")
        if origin and origin != expected:
            return JSONResponse({"detail": "Origem não autorizada"}, status_code=403)
        try:
            size = int(request.headers.get("content-length", "0") or 0)
        except ValueError:
            return JSONResponse({"detail": "Content-Length inválido"}, status_code=400)
        if size > 3_000_000:
            return JSONResponse({"detail": "Envio excede 3 MB"}, status_code=413)
    response = await call_next(request)
    response.headers.update(
        {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Referrer-Policy": "no-referrer",
            "Cache-Control": "no-store",
            "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
        }
    )
    return response


class Login(BaseModel):
    token: str = Field(max_length=200)


@app.post("/api/session")
def login(data: Login, request: Request, response: Response):
    ip = request.client.host if request.client else "unknown"
    now = time.time()
    q = attempts[ip]
    while q and q[0] < now - 60:
        q.popleft()
    if len(q) >= 10:
        raise HTTPException(429, "Muitas tentativas. Aguarde um minuto.")
    q.append(now)
    if not hmac.compare_digest(data.token.encode(), TOKEN.encode()):
        raise HTTPException(401, "Chave inválida.")
    q.clear()
    response.set_cookie(
        "sentinel_session",
        session_value(),
        httponly=True,
        samesite="strict",
        secure=request.url.scheme == "https",
        max_age=28800,
    )
    return {"ok": True}


@app.delete("/api/session")
def logout(response: Response):
    response.delete_cookie("sentinel_session")
    return {"ok": True}


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/ai/status", dependencies=[Depends(auth)])
def ai_status():
    return model_status()


@app.get("/api/config", dependencies=[Depends(auth)])
def config():
    return {
        "languages": sorted(set(EXTENSIONS.values())),
        "rules": RULES,
        "queue": os.getenv("QUEUE_MODE", "local"),
        "ai_model": os.getenv("OLLAMA_MODEL", "llama3.2:3b"),
        "max_files": 100,
        "max_bytes": MAX_TOTAL,
    }


class Source(BaseModel):
    path: str = Field(min_length=1, max_length=240)
    content: str = Field(max_length=MAX_FILE)


class ScanInput(BaseModel):
    name: str = Field(default="Meu projeto", min_length=1, max_length=120)
    files: list[Source] = Field(min_length=1, max_length=100)
    threshold: Literal["critical", "high", "medium", "low"] = "high"
    use_ai: bool = False

    @model_validator(mode="after")
    def validate_files(self):
        total = 0
        paths = set()
        for f in self.files:
            f.path = safe_path(f.path)
            if f.path in paths:
                raise ValueError("Arquivos duplicados")
            paths.add(f.path)
            n = len(f.content.encode())
            total += n
            if n > MAX_FILE:
                raise ValueError("Arquivo maior que 200 KB")
        if total > MAX_TOTAL:
            raise ValueError("Conteúdo maior que 2 MB")
        if not any(path_language(f.path) for f in self.files):
            raise ValueError("Nenhuma linguagem suportada")
        return self


def create(data, demo=False):
    expire_scans()
    with Session() as db:
        active = db.scalar(
            select(func.count())
            .select_from(Scan)
            .where(Scan.status.in_(["queued", "running"]))
        )
        if active >= 8:
            raise HTTPException(429, "Fila cheia. Aguarde as análises atuais.")
        s = Scan(
            id=str(uuid.uuid4()), name=data.name, payload=data.model_dump(), demo=demo
        )
        db.add(s)
        db.commit()
        scan_id = s.id
    try:
        dispatch(scan_id)
    except Exception:
        with Session() as db:
            s = db.get(Scan, scan_id)
            s.status = "failed"
            s.payload = None
            s.error = "Fila indisponível. Verifique Redis e worker."
            db.commit()
        raise HTTPException(503, "Fila indisponível")
    return {"id": scan_id, "status": "queued"}


@app.post("/api/scans", status_code=202, dependencies=[Depends(auth)])
def scan(data: ScanInput):
    return create(data)


@app.post("/api/scans/demo", status_code=202, dependencies=[Depends(auth)])
def demo():
    files = [
        Source(path="demo/" + p.name, content=p.read_text())
        for p in sorted((ROOT / "examples/vulnerable").iterdir())
        if p.is_file()
    ]
    return create(ScanInput(name="Laboratório • quatro linguagens", files=files), True)


@app.post("/api/scans/upload", status_code=202, dependencies=[Depends(auth)])
async def upload(
    file: UploadFile = File(...),
    name: str = Form("Projeto importado"),
    threshold: Literal["critical", "high", "medium", "low"] = Form("high"),
    use_ai: bool = Form(False),
):
    raw = await file.read(MAX_TOTAL + 1)
    if len(raw) > MAX_TOTAL:
        raise HTTPException(413, "Arquivo excede 2 MB")
    files = []
    try:
        if (file.filename or "").lower().endswith(".zip"):
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                entries = [i for i in z.infolist() if not i.is_dir()]
                if len(entries) > 500:
                    raise ValueError("ZIP contém mais de 500 entradas")
                if sum(i.file_size for i in entries) > MAX_TOTAL:
                    raise ValueError("ZIP descompactado excede 2 MB")
                for i in entries:
                    path = safe_path(i.filename)
                    if (i.external_attr >> 16) & 0o170000 == 0o120000:
                        raise ValueError("Links simbólicos não são aceitos")
                    if any(
                        x in path.split("/")
                        for x in (
                            ".git",
                            "node_modules",
                            ".venv",
                            "venv",
                            "dist",
                            "build",
                            "__pycache__",
                        )
                    ):
                        continue
                    if not path_language(path):
                        continue
                    if i.file_size > MAX_FILE:
                        raise ValueError("Arquivo excede 200 KB")
                    files.append(
                        Source(path=path, content=z.read(i).decode("utf-8-sig"))
                    )
        else:
            files = [
                Source(
                    path=safe_path(file.filename or "source.py"),
                    content=raw.decode("utf-8-sig"),
                )
            ]
        return create(
            ScanInput(name=name, files=files, threshold=threshold, use_ai=use_ai)
        )
    except (ValueError, zipfile.BadZipFile, RuntimeError) as e:
        raise HTTPException(422, str(e)[:300])


@app.get("/api/scans", dependencies=[Depends(auth)])
def scans():
    expire_scans()
    with Session() as db:
        return [
            serialize(s)
            for s in db.scalars(
                select(Scan).order_by(Scan.created_at.desc()).limit(100)
            )
        ]


@app.get("/api/scans/{scan_id}", dependencies=[Depends(auth)])
def detail(scan_id: str):
    expire_scans()
    with Session() as db:
        s = db.get(Scan, scan_id)
        if not s:
            raise HTTPException(404, "Análise não encontrada")
        return serialize(s, True)


@app.delete("/api/scans/{scan_id}", dependencies=[Depends(auth)])
def delete(scan_id: str):
    with Session() as db:
        s = db.get(Scan, scan_id)
        if not s:
            raise HTTPException(404, "Análise não encontrada")
        if s.status in ("running", "queued"):
            raise HTTPException(409, "Aguarde a conclusão para excluir")
        db.delete(s)
        db.commit()
        return {"ok": True}


@app.get("/api/scans/{scan_id}/export", dependencies=[Depends(auth)])
def export(scan_id: str, format: Literal["json", "sarif"] = "json"):
    s = detail(scan_id)
    if not s["result"]:
        raise HTTPException(409, "Resultado ainda indisponível")
    result = sarif(s["result"]) if format == "sarif" else s
    return Response(
        json.dumps(result, ensure_ascii=False, indent=2),
        media_type="application/json",
        headers={
            "Content-Disposition": f'attachment; filename="sentinel-{scan_id}.{format}"'
        },
    )


@app.get("/")
def home():
    return FileResponse(ROOT / "web/index.html")


app.mount("/static", StaticFiles(directory=ROOT / "web"), name="static")
app.add_middleware(BodyLimitMiddleware)
