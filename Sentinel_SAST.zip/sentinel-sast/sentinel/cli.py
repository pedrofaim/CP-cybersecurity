import argparse, json, sys
from pathlib import Path
from .engine import analyze, path_language
from .reports import sarif


def main():
    p = argparse.ArgumentParser(
        description="Sentinel SAST • exit 0=passed, 1=blocked, 2=error"
    )
    p.add_argument("path")
    p.add_argument(
        "--threshold", choices=["critical", "high", "medium", "low"], default="high"
    )
    p.add_argument("--output", default="sentinel-report.json")
    p.add_argument("--sarif")
    a = p.parse_args()
    try:
        root = Path(a.path).resolve()
        paths = [root] if root.is_file() else sorted(root.rglob("*"))
        files = []
        for f in paths:
            if not f.is_file() or f.is_symlink() or not path_language(str(f)):
                continue
            relative = f.relative_to(root) if root.is_dir() else Path(f.name)
            if any(
                part
                in (
                    ".git",
                    ".venv",
                    "node_modules",
                    "venv",
                    "dist",
                    "build",
                    "__pycache__",
                )
                for part in relative.parts
            ):
                continue
            if f.stat().st_size > 200_000:
                raise ValueError(f"Arquivo excede limite: {relative}")
            files.append(
                {
                    "path": str(relative).replace("\\", "/"),
                    "content": f.read_text(encoding="utf-8-sig"),
                }
            )
            if (
                len(files) > 100
                or sum(len(x["content"].encode()) for x in files) > 2_000_000
            ):
                raise ValueError("Projeto excede 100 arquivos / 2 MB")
        result = analyze(files, a.threshold)
        Path(a.output).write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        if a.sarif:
            Path(a.sarif).write_text(
                json.dumps(sarif(result), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        print(json.dumps(result["summary"], ensure_ascii=False))
        return 1 if result["summary"]["gate"] == "blocked" else 0
    except Exception as e:
        print(f"Erro de análise: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
