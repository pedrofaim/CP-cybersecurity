import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from celery import Celery
from sqlalchemy import update
from .storage import Session, Scan
from .engine import analyze
from .ai import advise

celery = Celery("sentinel", broker=os.getenv("REDIS_URL", "redis://localhost:6379/0"))
celery.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    task_ignore_result=True,
    worker_prefetch_multiplier=1,
    task_time_limit=360,
    broker_connection_retry_on_startup=True,
)
pool = ThreadPoolExecutor(max_workers=2)


@celery.task(name="sentinel.scan")
def run_scan(scan_id):
    # Conditional state transition prevents duplicate Celery deliveries from reprocessing.
    with Session() as db:
        claimed = db.execute(
            update(Scan)
            .where(Scan.id == scan_id, Scan.status == "queued")
            .values(status="running")
        )
        db.commit()
        if not claimed.rowcount:
            return
        scan = db.get(Scan, scan_id)
        payload = scan.payload
    try:
        result = analyze(payload["files"], payload.get("threshold", "high"))
        if payload.get("use_ai"):
            for finding in result["findings"][:3]:
                finding["ai"] = advise(finding)
                if finding["ai"]["status"] == "unavailable":
                    break
        with Session() as db:
            scan = db.get(Scan, scan_id)
            if scan and scan.status == "running":
                scan.result = result
                scan.status = "completed"
                scan.payload = None
                scan.finished_at = datetime.now(timezone.utc)
                db.commit()
    except Exception:
        with Session() as db:
            scan = db.get(Scan, scan_id)
            if scan and scan.status == "running":
                scan.status = "failed"
                scan.error = "Falha no motor. Verifique dependências e logs do serviço. Nenhum resultado deve ser interpretado como aprovação."
                scan.payload = None
                scan.finished_at = datetime.now(timezone.utc)
                db.commit()
        raise


def dispatch(scan_id):
    if os.getenv("QUEUE_MODE", "local") == "celery":
        run_scan.delay(scan_id)
    else:
        pool.submit(run_scan, scan_id)
