"""AST/Tree-sitter rules and bounded intraprocedural taint analysis. Never executes input."""

import ast
import hashlib
import re
from pathlib import PurePosixPath
from .rules import RULES, SEVERITIES, WEIGHTS

EXTENSIONS = {
    ".py": "Python",
    ".js": "JavaScript",
    ".jsx": "JavaScript",
    ".mjs": "JavaScript",
    ".cjs": "JavaScript",
    ".ts": "TypeScript",
    ".tsx": "TypeScript",
    ".java": "Java",
}
SECRET = re.compile(
    r"(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|private[_-]?key)", re.I
)
SOURCE = re.compile(
    r"\b(?:request\.(?:args|form|json|values|data|GET|POST|query_params)|req\.(?:query|body|params)|request\.(?:getParameter|getHeader|getQueryString)|System\.getenv|location\.(?:search|hash)|document\.location|input\s*\()"
)


def redact(text):
    # Do not retain literal secrets in snippets, reports, prompts or SQL rows.
    return re.sub(
        r"""(?i)((?:[\w]*password|passwd|pwd|[\w]*secret|api_?key|access_?token)\s*[:=]\s*)('[^'\n]*'|"[^"\n]*")""",
        r'\1"[REDACTED]"',
        text,
    )


def path_language(path):
    return EXTENSIONS.get(PurePosixPath(path).suffix.lower())


def safe_path(path):
    p = PurePosixPath(path.replace("\\", "/"))
    if (
        p.is_absolute()
        or ".." in p.parts
        or not p.parts
        or ":" in str(p)
        or len(str(p)) > 240
    ):
        raise ValueError("Nome de arquivo inválido")
    return str(p)


class Collector:
    def __init__(self, path, source, language):
        self.path, self.source, self.language = path, source, language
        self.lines = source.splitlines()
        self.findings = []
        self.secret_lines = set()

    def add(self, rule, line, flow=None, confidence="medium"):
        if any(f["rule_id"] == rule and f["line"] == line for f in self.findings):
            return
        base = RULES[rule]
        snippet = "\n".join(
            f"{n + 1:>4}  {redact(self.lines[n])}"
            for n in range(max(0, line - 3), min(len(self.lines), line + 2))
        )
        self.findings.append(
            dict(
                base,
                id=hashlib.sha256(f"{self.path}:{line}:{rule}".encode()).hexdigest()[
                    :16
                ],
                rule_id=rule,
                file=self.path,
                line=line,
                language=self.language,
                confidence=confidence,
                snippet=snippet,
                flow=flow or [],
                engine="Python AST" if self.language == "Python" else "Tree-sitter",
                ai=None,
            )
        )


def unique_flow(flow):
    out = []
    for x in flow:
        if x not in out:
            out.append(x)
    return out if len(out) <= 12 else [out[0], *out[-11:]]


class PythonAnalyzer:
    def __init__(self, collector):
        self.c = collector
        self.aliases = {}

    def name(self, node):
        if isinstance(node, ast.Name):
            return self.aliases.get(node.id, node.id)
        if isinstance(node, ast.Attribute):
            return self.name(node.value) + "." + node.attr
        return ""

    def text(self, node):
        return ast.get_source_segment(self.c.source, node) or ""

    def taint(self, node, env):
        if node is None:
            return []
        if isinstance(node, ast.Call) and self.name(node.func) in ("int", "float"):
            return []
        source_name = (
            self.name(node.func) + "("
            if isinstance(node, ast.Call)
            else self.name(node)
        )
        if source_name.startswith("flask.request."):
            source_name = source_name.removeprefix("flask.")
        if SOURCE.match(source_name or self.text(node)) and isinstance(
            node, (ast.Call, ast.Attribute, ast.Subscript)
        ):
            return [dict(line=node.lineno, label="Entrada externa", kind="source")]
        flow = []
        if isinstance(node, ast.Name):
            flow += env.get(node.id, [])
        for child in ast.iter_child_nodes(node):
            flow += self.taint(child, env)
        return unique_flow(flow)

    def inspect(self, node, env):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            return
        if isinstance(node, ast.Call):
            name = self.name(node.func)
            args = node.args
            flow = self.taint(args[0], env) if args else []
            sink = (
                flow + [dict(line=node.lineno, label=name, kind="sink")] if flow else []
            )
            if name in ("eval", "exec", "builtins.eval", "builtins.exec"):
                self.c.add("S002", node.lineno, sink, "high")
            if name.endswith((".execute", ".executemany", ".raw")) and flow:
                self.c.add("S003", node.lineno, sink, "high")
            shell = any(
                k.arg == "shell"
                and isinstance(k.value, ast.Constant)
                and k.value.value is True
                for k in node.keywords
            )
            if name in ("os.system", "os.popen") or (
                name.startswith("subprocess.") and shell
            ):
                self.c.add("S004", node.lineno, sink, "high" if flow else "medium")
            if name in ("hashlib.md5", "hashlib.sha1"):
                self.c.add("S006", node.lineno, confidence="high")
            if name in (
                "pickle.loads",
                "pickle.load",
                "marshal.loads",
                "yaml.unsafe_load",
            ):
                self.c.add("S007", node.lineno, sink)
            if (
                name
                in (
                    "requests.get",
                    "requests.post",
                    "httpx.get",
                    "httpx.post",
                    "urllib.request.urlopen",
                )
                and flow
            ):
                self.c.add("S008", node.lineno, sink, "high")
            if name in ("open", "builtins.open") and flow:
                self.c.add("S009", node.lineno, sink, "high")
            if (
                name
                in (
                    "render_template_string",
                    "flask.render_template_string",
                    "markupsafe.Markup",
                )
                and flow
            ):
                self.c.add("S005", node.lineno, sink, "high")
        for child in ast.iter_child_nodes(node):
            self.inspect(child, env)

    def block(self, nodes, env):
        for node in nodes:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                for a in node.names:
                    self.aliases[a.asname or a.name] = (
                        (node.module + ".")
                        if isinstance(node, ast.ImportFrom) and node.module
                        else ""
                    ) + a.name
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                local = dict(env)
                outer_aliases = dict(self.aliases)
                args = node.args.posonlyargs + node.args.args + node.args.kwonlyargs
                args += [a for a in (node.args.vararg, node.args.kwarg) if a]
                for arg in args:
                    local.pop(arg.arg, None)
                    self.aliases.pop(arg.arg, None)
                self.block(node.body, local)
                self.aliases = outer_aliases
                continue
            if isinstance(node, ast.ClassDef):
                outer_aliases = dict(self.aliases)
                self.block(node.body, dict(env))
                self.aliases = outer_aliases
                continue
            if isinstance(node, ast.If):
                self.inspect(node.test, env)
                a, b = dict(env), dict(env)
                self.block(node.body, a)
                self.block(node.orelse, b)
                for key in a.keys() | b.keys():
                    env[key] = unique_flow(a.get(key, []) + b.get(key, []))
                continue
            if isinstance(node, (ast.For, ast.While, ast.Try, ast.With, ast.AsyncWith)):
                branch = dict(env)
                if hasattr(node, "test"):
                    self.inspect(node.test, env)
                if hasattr(node, "iter"):
                    self.inspect(node.iter, env)
                    if isinstance(node.target, ast.Name):
                        branch[node.target.id] = self.taint(node.iter, env)
                for item in getattr(node, "items", []):
                    self.inspect(item.context_expr, env)
                self.block(node.body, branch)
                for handler in getattr(node, "handlers", []):
                    self.block(handler.body, branch)
                self.block(getattr(node, "orelse", []), branch)
                self.block(getattr(node, "finalbody", []), branch)
                for key in branch:
                    env[key] = unique_flow(env.get(key, []) + branch[key])
                continue
            self.inspect(node, env)
            if isinstance(node, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                value = node.value
                targets = (
                    node.targets if isinstance(node, ast.Assign) else [node.target]
                )
                for target in targets:
                    name = self.text(target)
                    if (
                        SECRET.search(name)
                        and isinstance(value, ast.Constant)
                        and isinstance(value.value, str)
                        and len(value.value) >= 4
                    ):
                        self.c.add("S001", node.lineno, confidence="high")
                        self.c.secret_lines.update(
                            range(node.lineno, value.end_lineno + 1)
                        )
                    if isinstance(target, (ast.Tuple, ast.List)):
                        values = (
                            value.elts
                            if isinstance(value, (ast.Tuple, ast.List))
                            else None
                        )
                        for i, binding in enumerate(target.elts):
                            if isinstance(binding, ast.Name):
                                env[binding.id] = self.taint(
                                    values[i] if values and i < len(values) else value,
                                    env,
                                )
                    if isinstance(target, ast.Name):
                        flow = self.taint(value, env)
                        if isinstance(node, ast.AugAssign):
                            flow = unique_flow(env.get(target.id, []) + flow)
                        env[target.id] = (
                            unique_flow(
                                flow
                                + [
                                    dict(
                                        line=node.lineno,
                                        label=f"Propagação: {target.id}",
                                        kind="propagation",
                                    )
                                ]
                            )
                            if flow
                            else []
                        )


def tree_parser(language, path):
    from tree_sitter import Language, Parser

    if language == "JavaScript":
        import tree_sitter_javascript as grammar

        lang = grammar.language()
    elif language == "Java":
        import tree_sitter_java as grammar

        lang = grammar.language()
    else:
        import tree_sitter_typescript as grammar

        lang = (
            grammar.language_tsx()
            if path.endswith(".tsx")
            else grammar.language_typescript()
        )
    return Parser(Language(lang))


class TreeAnalyzer:
    FUNCTIONS = {
        "function_declaration",
        "function_expression",
        "arrow_function",
        "method_declaration",
        "constructor_declaration",
        "method_definition",
        "generator_function_declaration",
        "generator_function",
    }

    def __init__(self, c):
        self.c = c
        self.raw = c.source.encode()
        self.command_objects = {"child_process", "childProcess", "shell"}
        self.command_functions = {"exec", "execSync"}
        # Resolve standard Node command imports without treating RegExp.exec as a shell.
        for match in re.finditer(
            r"(?:import\s+\*\s+as|(?:const|let|var))\s+(\w+)\s*(?:from\s*|=\s*require\(\s*)['\"](?:node:)?child_process['\"]",
            c.source,
        ):
            self.command_objects.add(match.group(1))
        for match in re.finditer(
            r"import\s*\{([^}]+)\}\s*from\s*['\"](?:node:)?child_process['\"]", c.source
        ):
            for item in match.group(1).split(","):
                names = re.split(r"\s+as\s+", item.strip())
                if names[0] in ("exec", "execSync"):
                    self.command_functions.add(names[-1])

    def text(self, n):
        return self.raw[n.start_byte : n.end_byte].decode() if n else ""

    def taint(self, n, env):
        if n is None:
            return []
        text = self.text(n)
        if n.type in ("call_expression", "method_invocation") and re.match(
            r"^(?:parseInt|parseFloat|Number|Integer\.parseInt)\(", text
        ):
            return []
        if n.type not in (
            "string",
            "string_literal",
            "comment",
            "template_chars",
        ) and SOURCE.match(text):
            # only source expressions, never treat a whole function/block as a source
            if n.type in (
                "member_expression",
                "subscript_expression",
                "call_expression",
                "method_invocation",
                "field_access",
            ):
                return [
                    dict(
                        line=n.start_point.row + 1,
                        label="Entrada externa",
                        kind="source",
                    )
                ]
        if n.type == "identifier":
            return env.get(text, [])
        flow = []
        for ch in n.named_children:
            flow += self.taint(ch, env)
        return unique_flow(flow)

    def walk(self, n, env):
        if n.type in self.FUNCTIONS:
            local = dict(env)
            params = n.child_by_field_name("parameters") or n.child_by_field_name(
                "parameter"
            )
            if params:
                stack = [params]
                while stack:
                    x = stack.pop()
                    if x.type == "identifier":
                        local.pop(self.text(x), None)
                    stack.extend(x.named_children)
            for ch in n.named_children:
                if ch != params:
                    self.walk(ch, local)
            return
        if n.type in (
            "for_statement",
            "for_in_statement",
            "enhanced_for_statement",
            "while_statement",
            "do_statement",
            "try_statement",
        ):
            branch = dict(env)
            update = n.child_by_field_name("increment") or n.child_by_field_name(
                "update"
            )
            for ch in n.named_children:
                if ch != update:
                    self.walk(ch, branch)
            if update:
                self.walk(update, branch)
            for k, v in branch.items():
                env[k] = unique_flow(env.get(k, []) + v)
            return
        if n.type in ("if_statement", "switch_statement"):
            branches = []
            for ch in n.named_children:
                branch = dict(env)
                self.walk(ch, branch)
                branches.append(branch)
            for branch in branches:
                for k, v in branch.items():
                    env[k] = unique_flow(env.get(k, []) + v)
            return
        # Evaluate children first, retaining statement order.
        for ch in n.named_children:
            self.walk(ch, env)
        line = n.start_point.row + 1
        if n.type in (
            "variable_declarator",
            "assignment_expression",
            "augmented_assignment_expression",
            "pair",
        ):
            target = (
                n.child_by_field_name("name")
                or n.child_by_field_name("left")
                or n.child_by_field_name("key")
            )
            value = n.child_by_field_name("value") or n.child_by_field_name("right")
            name = self.text(target)
            val = self.text(value)
            if (
                SECRET.search(name)
                and value
                and value.type in ("string", "string_literal")
                and len(val) > 5
            ):
                self.c.add("S001", line, confidence="high")
                self.c.secret_lines.update(range(line, value.end_point.row + 2))
            flow = self.taint(value, env)
            if (
                name.endswith((".innerHTML", ".outerHTML"))
                and value
                and value.type not in ("string", "string_literal")
            ):
                self.c.add(
                    "S005",
                    line,
                    flow + [dict(line=line, label=name, kind="sink")] if flow else [],
                    "high" if flow else "medium",
                )
            if target and target.type in ("object_pattern", "array_pattern"):
                stack = [target]
                while stack:
                    binding = stack.pop()
                    if binding.type in (
                        "identifier",
                        "shorthand_property_identifier_pattern",
                    ):
                        env[self.text(binding)] = flow
                    elif binding.type == "pair_pattern":
                        child = binding.child_by_field_name("value")
                        if child:
                            stack.append(child)
                    else:
                        stack.extend(binding.named_children)
            if target and target.type == "identifier":
                if "+=" in self.text(n):
                    flow = unique_flow(env.get(name, []) + flow)
                env[name] = (
                    unique_flow(
                        flow
                        + [
                            dict(
                                line=line,
                                label=f"Propagação: {name}",
                                kind="propagation",
                            )
                        ]
                    )
                    if flow
                    else []
                )
        if n.type in (
            "call_expression",
            "method_invocation",
            "new_expression",
            "object_creation_expression",
        ):
            fn = (
                n.child_by_field_name("function")
                or n.child_by_field_name("constructor")
                or n.child_by_field_name("name")
                or n.child_by_field_name("type")
            )
            name = self.text(fn)
            obj = n.child_by_field_name("object")
            if obj:
                name = self.text(obj) + "." + name
            args = n.child_by_field_name("arguments")
            arguments = args.named_children if args else []
            first = arguments[0] if arguments else None
            flow = self.taint(first, env)
            sink = flow + [dict(line=line, label=name, kind="sink")] if flow else []
            if name in ("eval", "Function", "global.eval", "window.eval"):
                self.c.add("S002", line, sink, "high")
            if (
                re.search(r"\.(?:query|execute|executeQuery|executeUpdate)$", name)
                and flow
            ):
                self.c.add("S003", line, sink, "high")
            command = (
                self.c.language == "Java" and name.endswith(".exec") and flow
            ) or (
                self.c.language != "Java"
                and (
                    name in self.command_functions
                    or any(
                        name == obj + "." + method
                        for obj in self.command_objects
                        for method in ("exec", "execSync")
                    )
                )
            )
            if command:
                self.c.add("S004", line, sink, "high" if flow else "medium")
            if name.endswith((".createHash", ".getInstance")) and self.text(
                first
            ).strip("\"'").lower() in ("md5", "sha1", "sha-1"):
                self.c.add("S006", line, confidence="high")
            if name.endswith(".readObject"):
                self.c.add("S007", line, sink)
            if name in ("fetch", "axios.get", "axios.post") and flow:
                self.c.add("S008", line, sink, "high")
            if (
                re.search(r"(?:\.readFileSync|\.readFile|\.writeFileSync)$", name)
                and flow
            ):
                self.c.add("S009", line, sink, "high")
            if name.endswith((".write", ".send")) and flow:
                self.c.add("S005", line, sink, "medium")
            if self.c.language == "Java":
                if (
                    name
                    in (
                        "FileInputStream",
                        "FileOutputStream",
                        "FileReader",
                        "FileWriter",
                        "RandomAccessFile",
                        "java.io.FileInputStream",
                        "java.io.FileOutputStream",
                        "Files.readString",
                        "Files.readAllBytes",
                        "Files.write",
                        "Files.newInputStream",
                    )
                    and flow
                ):
                    self.c.add("S009", line, sink, "high")
                if name.endswith((".openConnection", ".openStream")):
                    url_flow = self.taint(obj, env)
                    if url_flow:
                        self.c.add(
                            "S008",
                            line,
                            url_flow + [dict(line=line, label=name, kind="sink")],
                            "medium",
                        )


def analyze_file(path, source):
    path = safe_path(path)
    language = path_language(path)
    if not language:
        return [], dict(file=path, status="unsupported", language=None)
    c = Collector(path, source, language)
    if language == "Python":
        try:
            tree = ast.parse(source)
        except (SyntaxError, ValueError, RecursionError) as ex:
            return [], dict(
                file=path,
                status="parse_error",
                language=language,
                message=f"Sintaxe inválida, linha {getattr(ex, 'lineno', 1)}",
            )
        try:
            PythonAnalyzer(c).block(tree.body, {})
        except RecursionError:
            return [], dict(
                file=path,
                status="parse_error",
                language=language,
                message="Estrutura profunda demais para o limite do analisador.",
            )
    else:
        tree = tree_parser(language, path).parse(source.encode())
        if tree.root_node.has_error:
            return [], dict(
                file=path,
                status="parse_error",
                language=language,
                message="Tree-sitter encontrou erro de sintaxe; corrija antes de confiar no resultado.",
            )
        try:
            TreeAnalyzer(c).walk(tree.root_node, {})
        except RecursionError:
            return [], dict(
                file=path,
                status="parse_error",
                language=language,
                message="Estrutura profunda demais para o limite do analisador.",
            )
    for f in c.findings:
        f["snippet"] = "\n".join(
            f"{n + 1:>4}  "
            + (
                "[REDACTED: linha com credencial literal]"
                if n + 1 in c.secret_lines
                else redact(c.lines[n])
            )
            for n in range(max(0, f["line"] - 3), min(len(c.lines), f["line"] + 2))
        )
    return c.findings, dict(
        file=path, status="analyzed", language=language, lines=len(source.splitlines())
    )


def analyze(files, threshold="high"):
    findings = []
    details = []
    for item in files:
        f, d = analyze_file(item["path"], item["content"])
        findings += f
        details.append(d)
    findings.sort(key=lambda f: (SEVERITIES.index(f["severity"]), f["file"], f["line"]))
    counts = {s: sum(f["severity"] == s for f in findings) for s in SEVERITIES}
    errors = [d for d in details if d["status"] == "parse_error"]
    analyzed = sum(d["status"] == "analyzed" for d in details)
    blocking = sum(counts[s] for s in SEVERITIES[: SEVERITIES.index(threshold) + 1])
    return dict(
        findings=findings,
        files=details,
        summary=dict(
            counts=counts,
            total=len(findings),
            files_analyzed=analyzed,
            files_skipped=len(details) - analyzed,
            lines=sum(d.get("lines", 0) for d in details),
            risk_score=min(100, sum(counts[s] * WEIGHTS[s] for s in SEVERITIES)),
            gate="blocked" if blocking or errors or not analyzed else "passed",
            gate_threshold=threshold,
            blocking_findings=blocking,
            parse_errors=len(errors),
            languages=sorted(
                {d["language"] for d in details if d["status"] == "analyzed"}
            ),
        ),
    )
