"""Sentinel SAST: educational, static-only security analysis."""

__version__ = "1.0.0"
