@echo off
setlocal
cd /d "%~dp0"
title Sentinel - Validacao completa
call INICIAR_LOCAL_VERIFICACAO.bat
if errorlevel 1 goto finish
".venv\Scripts\python.exe" scripts\validate.py
:finish
echo.
echo Verifique o resultado acima. Evidencias: docs\evidence-local
pause
