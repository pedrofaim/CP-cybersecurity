@echo off
setlocal
cd /d "%~dp0"
title Sentinel SAST
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 (
  py -3.12 scripts\start_windows.py --mode ai
  goto finish
)
python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
if not errorlevel 1 (
  python scripts\start_windows.py --mode ai
  goto finish
)
echo Python 3.12 nao encontrado. Instale o Python 3.12 e execute este arquivo novamente.
echo Na instalacao, habilite Add python.exe to PATH.
:finish
echo.
pause
