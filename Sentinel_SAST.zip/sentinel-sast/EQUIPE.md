# Equipe

Disciplina: Cybersecurity — Projeto Integrador SAST e DevSecOps
Curso: Engenharia de Software — FIAP
Prazo informado: 20/10/2026 às 23:59

Preencha e confirme o grupo antes da submissão. Não foram presumidos integrantes de outros trabalhos.

| Integrante | RM | Contribuição efetivamente realizada |
|---|---|---|
| Pedro Henrique Faim dos Santos | 557440 | Registrar contribuição efetivamente realizada |
| A preencher | A preencher | A preencher |
| A preencher | A preencher | A preencher |
| A preencher | A preencher | A preencher |

O documento do professor menciona grupos de 4–5 integrantes; confirme qualquer composição diferente.
