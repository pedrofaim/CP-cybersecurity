// Laboratório intencionalmente vulnerável. Não executar.
function profile(req: any, element: HTMLElement) {
  const name: string = req.query.name;
  element.innerHTML = name;
  const target = req.query.url;
  fetch(target);
}
