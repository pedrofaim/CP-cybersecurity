// Laboratório intencionalmente vulnerável. Não executar.
const apiKey = "demo-only-not-a-real-key";
function search(req, res, db) {
  const term = req.query.term;
  const query = "SELECT * FROM products WHERE name = '" + term + "'";
  db.query(query);
  eval(req.body.expression);
  res.send(req.query.html);
}
