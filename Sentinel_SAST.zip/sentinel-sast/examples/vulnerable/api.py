# Laboratório intencionalmente vulnerável. Não executar.
from flask import request
import os
import hashlib
import pickle
import requests

PASSWORD = 'demo-only-not-a-real-password'

def search(db):
    user = request.args.get('user')
    query = "SELECT * FROM users WHERE name = '" + user + "'"
    db.execute(query)
    command = request.args.get('command')
    os.system(command)
    eval(request.args.get('expression'))
    return requests.get(request.args.get('url'))

def weak_digest(value):
    return hashlib.md5(value.encode()).hexdigest()

def load_object(raw):
    return pickle.loads(raw)
