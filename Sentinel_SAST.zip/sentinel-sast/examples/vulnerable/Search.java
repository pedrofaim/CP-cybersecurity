// Laboratório intencionalmente vulnerável. Não executar.
class Search {
  void search(HttpServletRequest request, Statement statement) throws Exception {
    String name = request.getParameter("name");
    String query = "SELECT * FROM users WHERE name = '" + name + "'";
    statement.executeQuery(query);
  }
}
