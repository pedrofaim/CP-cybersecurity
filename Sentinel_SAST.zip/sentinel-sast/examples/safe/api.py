import os
import hashlib
from flask import request

PASSWORD = os.environ.get('DATABASE_PASSWORD')

def search(db):
    user = request.args.get('user')
    db.execute('SELECT * FROM users WHERE name = %s', (user,))

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()
