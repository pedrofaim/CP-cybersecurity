function search(req, res, db) {
  const term = req.query.term;
  db.query('SELECT * FROM products WHERE name = ?', [term]);
  return JSON.parse(req.body.data);
}
