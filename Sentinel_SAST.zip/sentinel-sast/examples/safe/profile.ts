function profile(req: any, element: HTMLElement) {
  const name: string = req.query.name;
  element.textContent = name;
}
