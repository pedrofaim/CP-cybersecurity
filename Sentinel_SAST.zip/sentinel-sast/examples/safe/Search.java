class Search {
  void search(HttpServletRequest request, Connection connection) throws Exception {
    String name = request.getParameter("name");
    PreparedStatement query = connection.prepareStatement("SELECT * FROM users WHERE name = ?");
    query.setString(1, name);
    query.executeQuery();
  }
}
