@echo off
setlocal
cd /d "%~dp0"
py -3.12 -c "import sys" >nul 2>&1
if not errorlevel 1 (
 py -3.12 scripts\start_windows.py --mode local --port 8765 --check --no-browser
 exit /b
)
python -c "import sys; sys.exit(0 if sys.version_info[:2] == (3,12) else 1)" >nul 2>&1
if errorlevel 1 (
 echo Instale Python 3.12 com Add python.exe to PATH.
 exit /b 1
)
python scripts\start_windows.py --mode local --port 8765 --check --no-browser
exit /b
