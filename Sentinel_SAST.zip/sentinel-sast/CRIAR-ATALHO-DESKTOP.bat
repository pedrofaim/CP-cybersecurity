@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Sentinel SAST - Atalho

powershell -NoProfile -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\Sentinel SAST.lnk'); $s.TargetPath=(Resolve-Path '.\ABRIR-SENTINEL.bat').Path; $s.WorkingDirectory=(Get-Location).Path; $s.IconLocation='%SystemRoot%\System32\shell32.dll,12'; $s.Description='Abrir a plataforma Sentinel SAST'; $s.Save()"
if not errorlevel 1 (
  echo  [OK] Atalho "Sentinel SAST" criado na area de trabalho.
  echo       A partir de agora, dois cliques no atalho abrem a plataforma.
) else (
  echo [!] Nao foi possivel criar o atalho. Use ABRIR-SENTINEL.bat na pasta do projeto.
)
echo.
pause
