"""Development fallback: local queue + SQLite. Docker is the academic deployment."""

import os
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
os.chdir(root)
sys.path.insert(0, str(root))
if not (root / ".env").exists():
    raise SystemExit("Execute primeiro: python scripts/setup.py")
for line in (root / ".env").read_text(encoding="utf-8").splitlines():
    if "=" in line and not line.lstrip().startswith("#"):
        key, value = line.split("=", 1)
        os.environ.setdefault(key, value)
os.environ.setdefault("QUEUE_MODE", "local")
if not os.getenv("API_TOKEN"):
    raise SystemExit("Defina API_TOKEN em .env")
import uvicorn

uvicorn.run(
    "sentinel.api:app", host="127.0.0.1", port=int(os.getenv("SENTINEL_PORT", "8000"))
)
