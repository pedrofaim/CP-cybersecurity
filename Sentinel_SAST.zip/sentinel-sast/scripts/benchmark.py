"""Report transparent case-level metrics, including four known false negatives."""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sentinel.engine import analyze_file


def metrics(rows):
    tp = sum(r["vulnerable"] and r["detected"] for r in rows)
    fp = sum(not r["vulnerable"] and r["detected"] for r in rows)
    fn = sum(r["vulnerable"] and not r["detected"] for r in rows)
    tn = sum(not r["vulnerable"] and not r["detected"] for r in rows)
    precision = tp / (tp + fp) if tp + fp else None
    recall = tp / (tp + fn) if tp + fn else None
    return dict(
        cases=len(rows),
        true_positive=tp,
        false_positive=fp,
        false_negative=fn,
        true_negative=tn,
        precision=precision,
        recall=recall,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="docs/evidence-local/benchmark.json")
    args = parser.parse_args()
    cases = json.loads((ROOT / "benchmark/cases.json").read_text(encoding="utf-8"))
    rows = []
    for case in cases:
        findings, detail = analyze_file(case["path"], case["code"])
        detected = any(f["rule_id"] == case["rule"] for f in findings)
        rows.append(
            {
                **case,
                "detected": detected,
                "parser_status": detail["status"],
                "baseline_match": detected == case["expected_detection"]
                and detail["status"] == "analyzed",
            }
        )
    report = dict(
        executed_at=datetime.now(timezone.utc).isoformat(),
        method="Um caso = presença/ausência da regra-alvo. Corpus sintético autoral; não é avaliação independente nem mede todas as falhas do arquivo.",
        overall=metrics(rows),
        by_language={
            language: metrics([r for r in rows if r["language"] == language])
            for language in sorted({r["language"] for r in rows})
        },
        cases=rows,
    )
    output = (ROOT / args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report["overall"], ensure_ascii=False))
    return 0 if all(r["baseline_match"] for r in rows) else 1


if __name__ == "__main__":
    raise SystemExit(main())
