"""Run a real local inference and save evidence only after schema validation."""

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sentinel.ai import advise
from sentinel.engine import analyze_file


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="docs/evidence-local/ollama-real.json")
    args = parser.parse_args()
    envfile = ROOT / ".env"
    if envfile.exists():
        for line in envfile.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip())
    finding = analyze_file(
        "review.py", 'query = "SELECT " + request.args.get("id")\ndb.execute(query)'
    )[0][0]
    answer = advise(finding)
    if answer["status"] != "complete":
        print(answer["explanation"])
        return 1
    output = (ROOT / args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(
            {
                "executed_at": datetime.now(timezone.utc).isoformat(),
                "finding": finding,
                "ai": answer,
                "review": "Requer revisão humana: contrato válido não prova correção semântica.",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print("Inferencia real concluida; revise " + str(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
