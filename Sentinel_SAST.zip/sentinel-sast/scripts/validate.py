"""Reproduce the local release checks; failures produce a nonzero exit status."""

import argparse
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="docs/evidence-local")
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    commands = [
        (
            "pytest",
            [
                sys.executable,
                "-m",
                "pytest",
                "-q",
                "--junitxml",
                str(output / "pytest.xml"),
            ],
            0,
        ),
        (
            "bandit",
            [
                sys.executable,
                "-m",
                "bandit",
                "-r",
                "sentinel",
                "scripts",
                "-ll",
                "-f",
                "json",
                "-o",
                str(output / "bandit.json"),
            ],
            0,
        ),
        (
            "self-scan",
            [
                sys.executable,
                "-m",
                "sentinel.cli",
                "sentinel",
                "--output",
                str(output / "self-scan.json"),
            ],
            0,
        ),
        (
            "safe",
            [
                sys.executable,
                "-m",
                "sentinel.cli",
                "examples/safe",
                "--output",
                str(output / "safe.json"),
            ],
            0,
        ),
        (
            "vulnerable",
            [
                sys.executable,
                "-m",
                "sentinel.cli",
                "examples/vulnerable",
                "--output",
                str(output / "vulnerable.json"),
                "--sarif",
                str(output / "vulnerable.sarif"),
            ],
            1,
        ),
        (
            "benchmark",
            [
                sys.executable,
                "scripts/benchmark.py",
                "--output",
                str(output / "benchmark.json"),
            ],
            0,
        ),
    ]
    if shutil.which("node"):
        commands.append(("javascript", ["node", "--check", "web/app.js"], 0))
    results = []
    for name, command, expected in commands:
        print("\nVerificando: " + name, flush=True)
        result = subprocess.run(
            command,
            cwd=ROOT,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=180,
        )
        (output / (name + ".log")).write_text(
            result.stdout + result.stderr, encoding="utf-8"
        )
        passed = result.returncode == expected
        results.append(
            {
                "name": name,
                "passed": passed,
                "returncode": result.returncode,
                "expected_returncode": expected,
            }
        )
        print(("APROVADO" if passed else "FALHOU") + ": " + name)
        if not passed:
            print((result.stdout + result.stderr)[-3000:])
    report = {
        "executed_at": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(),
        "platform": platform.system(),
        "checks": results,
        "limitations": [
            "Docker, Windows nativo e inferência Ollama exigem validação no ambiente correspondente."
        ],
    }
    (output / "validation.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("\nEvidencias em: " + str(output))
    return 0 if all(x["passed"] for x in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
