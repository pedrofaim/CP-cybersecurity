/* Optional browser regression: npm install --no-save playwright; npx playwright install chromium. */
const {chromium}=require('playwright');
const fs=require('fs');
const path=require('path');
(async()=>{
  const url=process.env.UI_TEST_URL||'http://127.0.0.1:8000';
  const token=process.env.UI_TEST_TOKEN;
  if(!token)throw Error('UI_TEST_TOKEN deve conter a chave do banco descartável de teste.');
  const out=path.resolve(process.env.UI_OUTPUT||'docs/evidence/ui');fs.mkdirSync(out,{recursive:true});
  const options={headless:true};
  if(process.env.CHROMIUM_PATH){options.executablePath=process.env.CHROMIUM_PATH;options.args=['--no-sandbox','--disable-dev-shm-usage','--single-process','--use-gl=angle','--use-angle=swiftshader','--in-process-gpu','--enable-unsafe-swiftshader'];}
  const browser=await chromium.launch(options);
  try{
    const context=await browser.newContext({viewport:{width:1440,height:1000}});
    const page=await context.newPage();const errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    await page.goto(url);await page.locator('#token').fill(token);await page.locator('#login-form button').click();
    await page.locator('[data-action="demo"]').first().click();
    await page.locator('.metric-number').filter({hasText:'Bloqueado'}).waitFor();
    await page.waitForFunction(()=>document.querySelector('#nav-count').textContent==='14');
    await page.evaluate(()=>document.fonts.ready);
    await page.screenshot({path:path.join(out,'dashboard.png'),fullPage:true});
    await page.locator('[data-view="findings"]').first().click();
    await page.locator('#language-filter').selectOption('Java');
    if(await page.locator('#view-findings tbody tr[data-finding]').count()!==1)throw Error('Filtro Java inconsistente');
    await page.locator('#view-findings tbody tr[data-finding]').click();
    await page.locator('.flow-step.source').waitFor();
    await page.screenshot({path:path.join(out,'taint-java.png'),fullPage:true});
    await page.locator('[data-close="finding-dialog"]').click();
    await page.locator('[data-view="pipeline"]').first().click();
    await page.locator('#check-ai').click();
    await page.waitForFunction(()=>!document.querySelector('#check-ai').disabled);
    await page.locator('#new-scan').click();
    await page.locator('#file-name').fill('control.ts');await page.locator('#source-code').fill('const value: number = 42;');
    await page.locator('#project-name').fill('Controle do navegador');
    await page.locator('#submit-scan').click();
    await page.locator('.metric-number').filter({hasText:'Aprovado'}).waitFor();
    const scans=await (await context.request.get(url+'/api/scans')).json();
    const control=scans.find(s=>s.name==='Controle do navegador');
    const exported=await (await context.request.get(url+'/api/scans/'+control.id+'/export?format=sarif')).json();
    if(exported.version!=='2.1.0'||exported.runs[0].results.length!==0)throw Error('SARIF inválido');
    await page.locator('[data-view="history"]').first().click();
    await page.locator('[data-action="demo"]').first().click();
    await page.locator('[data-view="overview"]').first().click();
    await page.waitForFunction(()=>document.querySelector('#nav-count').textContent==='14');
    await page.setViewportSize({width:390,height:844});
    if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1))throw Error('Overflow da página no celular');
    await page.screenshot({path:path.join(out,'mobile.png'),fullPage:true});
    if(errors.length)throw Error(errors.join('\n'));
    const report={executed_at:new Date().toISOString(),passed:true,browser:await browser.version(),checks:['login real','laboratório: 14 achados em 4 linguagens','filtro Java','detalhe e origem do taint','disponibilidade Ollama','análise TypeScript segura','exportação SARIF','histórico','viewport 390 px sem overflow da página','zero exceções de JavaScript'],note:'Não comprova execução nativa no Windows.'};
    fs.writeFileSync(path.join(out,'browser.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
  }finally{await browser.close();}
})().catch(e=>{console.error(e.message);process.exitCode=1;});
