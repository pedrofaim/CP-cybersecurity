"""Exercise the deployed API, queue and storage with four-language controls."""

import json
import time
import http.client
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    token = next(
        x.split("=", 1)[1]
        for x in (ROOT / ".env").read_text().splitlines()
        if x.startswith("API_TOKEN=")
    )

    def api(path, data=None):
        connection = http.client.HTTPConnection("127.0.0.1", 8000, timeout=10)
        try:
            connection.request(
                "POST" if data is not None else "GET",
                "/api" + path,
                body=json.dumps(data) if data is not None else None,
                headers={
                    "Authorization": "Bearer " + token,
                    "Content-Type": "application/json",
                },
            )
            response = connection.getresponse()
            if response.status >= 400:
                raise RuntimeError("API retornou HTTP " + str(response.status))
            return json.loads(response.read())
        finally:
            connection.close()

    if api("/config")["queue"] != "celery":
        raise RuntimeError("Este teste exige QUEUE_MODE=celery")
    for folder, gate, total in [("vulnerable", "blocked", 14), ("safe", "passed", 0)]:
        files = [
            {"path": p.name, "content": p.read_text(encoding="utf-8")}
            for p in sorted((ROOT / "examples" / folder).iterdir())
            if p.is_file()
        ]
        scan = api("/scans", {"name": "Smoke Compose " + folder, "files": files})
        for _ in range(60):
            result = api("/scans/" + scan["id"])
            if result["status"] == "completed":
                break
            if result["status"] == "failed":
                raise RuntimeError("Worker falhou")
            time.sleep(1)
        else:
            raise RuntimeError("Worker não concluiu em 60 segundos")
        summary = result["result"]["summary"]
        if (
            summary["gate"] != gate
            or summary["total"] != total
            or len(summary["languages"]) != 4
        ):
            raise RuntimeError("Resultado inesperado no corpus " + folder)
        report = api("/scans/" + scan["id"] + "/export?format=sarif")
        if report["version"] != "2.1.0":
            raise RuntimeError("Exportação inválida")
        print("PASS: quatro linguagens; " + folder + "; gate " + gate)
    print("PASS: API → Redis → Celery → PostgreSQL → relatórios")


if __name__ == "__main__":
    main()
