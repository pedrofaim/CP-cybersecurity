"""Create installation-specific secrets. Does not overwrite existing settings."""

import secrets
from pathlib import Path

root = Path(__file__).resolve().parent.parent
env = root / ".env"
if env.exists():
    print(".env já existe; nenhuma alteração realizada.")
else:
    env.write_text(
        "API_TOKEN="
        + secrets.token_urlsafe(32)
        + "\nPOSTGRES_PASSWORD="
        + secrets.token_hex(24)
        + "\nOLLAMA_MODEL=llama3.2:3b\n",
        encoding="utf-8",
    )
    try:
        env.chmod(0o600)
    except OSError:
        pass
    print(
        ".env criado. Abra o arquivo e copie API_TOKEN para entrar no painel. Não envie .env ao GitHub."
    )
