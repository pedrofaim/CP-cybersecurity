"""One-click bootstrap; only standard library required before local installation."""

import argparse
import hashlib
import http.client
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
PORT = 8000
URL = f"http://localhost:{PORT}"


def run(args, **kwargs):
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True, **kwargs)


def request(path, token=None, data=None):
    connection = http.client.HTTPConnection("127.0.0.1", PORT, timeout=3)
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    try:
        connection.request(
            "POST" if data is not None else "GET",
            path,
            body=json.dumps(data) if data is not None else None,
            headers=headers,
        )
        response = connection.getresponse()
        content = response.read()
        if response.status >= 400:
            raise RuntimeError(
                f"API retornou HTTP {response.status}. Confira a chave e os logs."
            )
        return json.loads(content)
    finally:
        connection.close()


def ready():
    try:
        return (
            request("/api/openapi.json").get("info", {}).get("title") == "Sentinel SAST"
        )
    except (OSError, ValueError, RuntimeError):
        return False


def config():
    run([sys.executable, ROOT / "scripts/setup.py"])
    values = {}
    for line in (ROOT / ".env").read_text(encoding="utf-8").splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    if not values.get("API_TOKEN"):
        raise RuntimeError(
            "API_TOKEN vazio no arquivo .env. Preencha-o antes de continuar."
        )
    return values


def local_python():
    venv = ROOT / ".venv"
    executable = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if not executable.exists():
        print("Criando ambiente Python isolado...")
        run([sys.executable, "-m", "venv", venv])
    digest = hashlib.sha256(
        (ROOT / "requirements.txt").read_bytes()
        + (ROOT / "requirements-dev.txt").read_bytes()
    ).hexdigest()
    marker = venv / ".sentinel-requirements.sha256"
    if not marker.exists() or marker.read_text() != digest:
        print("Instalando dependencias. A primeira execucao precisa de internet...")
        run([executable, "-m", "pip", "install", "-r", ROOT / "requirements-dev.txt"])
        marker.write_text(digest)
    return executable


def wait_ready(process=None):
    for _ in range(60):
        if ready():
            return
        if process and process.poll() is not None:
            raise RuntimeError(
                "A API encerrou antes de iniciar. Veja .sentinel-runtime.log."
            )
        time.sleep(1)
    raise RuntimeError(
        f"A API nao ficou pronta em 60 segundos. Verifique a porta {PORT} e os logs."
    )


def smoke(token):
    request("/api/config", token)
    for name, code, expected in [
        ("vulneravel", "eval(input())", "blocked"),
        ("corrigido", "value = 42", "passed"),
    ]:
        result = request(
            "/api/scans",
            token,
            {
                "name": "Verificacao automatica - " + name,
                "files": [{"path": "check.py", "content": code}],
            },
        )
        for _ in range(60):
            scan = request("/api/scans/" + result["id"], token)
            if scan["status"] == "failed":
                raise RuntimeError("Motor falhou: " + str(scan.get("error")))
            if scan["status"] == "completed":
                break
            time.sleep(1)
        else:
            raise RuntimeError(
                "A analise nao concluiu em 60 segundos. Confira o worker."
            )
        if scan["result"]["summary"]["gate"] != expected:
            raise RuntimeError("Security Gate retornou resultado inesperado.")
    print(
        "APROVADO: API autenticada, analise vulneravel bloqueada e controle seguro aprovado."
    )


def show_access(token, no_browser):
    print("\nPainel: " + URL)
    print("Sua chave de acesso (cole no login; nao compartilhe):\n" + token)
    if not no_browser:
        webbrowser.open(URL)


def main():
    global PORT, URL
    os.chdir(ROOT)
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode", choices=["auto", "docker", "local", "ai"], default="auto"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Verifica o motor e encerra sem abrir navegador ou mostrar chave",
    )
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Use uma porta entre 1024 e 65535.")
    PORT = args.port
    URL = f"http://localhost:{PORT}"
    values = config()
    docker = shutil.which("docker")
    usable = False
    if docker and args.mode != "local":
        try:
            usable = (
                subprocess.run(
                    [docker, "info"], capture_output=True, timeout=20
                ).returncode
                == 0
            )
        except subprocess.TimeoutExpired:
            pass
    mode = args.mode
    if mode == "auto":
        mode = "docker" if usable else "local"
        if mode == "local":
            print(
                "Docker indisponivel. Iniciando modo de desenvolvimento com SQLite e fila local."
            )
    if mode in ("docker", "ai"):
        if PORT != 8000:
            raise RuntimeError(
                "A opcao --port personalizada funciona somente no modo local."
            )
        if not usable:
            raise RuntimeError(
                "Abra o Docker Desktop e aguarde a inicializacao; depois execute novamente."
            )
        if not values.get("POSTGRES_PASSWORD"):
            raise RuntimeError("POSTGRES_PASSWORD vazio no .env.")
        if mode == "ai":
            run([docker, "compose", "--profile", "ai", "up", "--build", "-d", "--wait"])
            print(
                "Baixando modelo local. Este passo usa internet e alguns GB de disco."
            )
            run(
                [
                    docker,
                    "compose",
                    "exec",
                    "-T",
                    "ollama",
                    "ollama",
                    "pull",
                    values.get("OLLAMA_MODEL", "llama3.2:3b"),
                ]
            )
        else:
            run([docker, "compose", "up", "--build", "-d", "--wait"])
        wait_ready()
        smoke(values["API_TOKEN"])
        if not args.check:
            show_access(values["API_TOKEN"], args.no_browser)
        return
    python = local_python()
    if ready():
        smoke(values["API_TOKEN"])
        if not args.check:
            show_access(values["API_TOKEN"], args.no_browser)
        return
    env = dict(os.environ, **values)
    env.update(
        QUEUE_MODE="local",
        DATABASE_URL="sqlite:///./sentinel.db",
        SENTINEL_PORT=str(PORT),
    )
    with (ROOT / ".sentinel-runtime.log").open("a", encoding="utf-8") as log:
        process = subprocess.Popen(
            [str(python), str(ROOT / "scripts/run_local.py")],
            cwd=ROOT,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
        )
        try:
            wait_ready(process)
            smoke(values["API_TOKEN"])
            if args.check:
                return
            show_access(values["API_TOKEN"], args.no_browser)
            print("\nDeixe esta janela aberta. Pressione Ctrl+C para parar.")
            process.wait()
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nServidor local encerrado.")
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        print("\nNao foi possivel concluir: " + str(error), file=sys.stderr)
        sys.exit(1)
