# Arquitetura técnica

## C4 — contexto (nível 1)

```mermaid
flowchart TB
    U["Desenvolvedor / equipe FIAP"] --> S["Sentinel SAST"]
    R["Código-fonte autorizado"] --> S
    S --> O["Relatórios e dashboard"]
    G["GitHub Actions"] --> S
    S --> G
```

O usuário fornece apenas arquivos autorizados. O Sentinel produz achados potenciais. No CI, o CLI funciona sem banco ou credencial da aplicação; seu exit code representa a política de bloqueio.

## C4 — contêineres (nível 2)

```mermaid
flowchart TB
    U["Navegador"] --> A["FastAPI + frontend"]
    A --> P[("PostgreSQL")]
    A --> R[("Redis / broker")]
    R --> W["Workers Celery"]
    W --> E["Motor AST / Tree-sitter"]
    W --> L["Ollama local"]
    W --> P
    G["GitHub Actions / CLI"] --> E
```

O frontend é servido pela API, evitando CORS e infraestrutura separada sem necessidade. API e workers usam a mesma imagem, com processos distintos e responsabilidades separadas. O motor é um módulo reutilizado pelo worker e pelo CLI. A decomposição não depende de chamar um processo de scanner para cada arquivo.

## Fluxo de uma análise

1. API autentica, valida nomes, tamanho, UTF-8, quantidade e formato.
2. PostgreSQL recebe a análise `queued` e o payload temporário.
3. Redis recebe apenas o UUID da tarefa (o código não é enviado no corpo da mensagem).
4. Worker faz transição condicional `queued → running` para evitar reprocessamento por entregas duplicadas.
5. Parsers constroem a árvore; regras inspecionam estrutura e propagação intraprocedural.
6. Se solicitada, a IA recebe até três achados mascarados e devolve JSON validado por Pydantic.
7. Worker grava resultado, remove payload e marca `completed`. Falhas tratadas marcam `failed`.
8. Frontend consulta o status e renderiza os resultados.

Estados: `queued`, `running`, `completed`, `failed`. Não há cancelamento, scheduler ou garantia de exactly-once. No reinício local, análises pendentes são marcadas como falhas e os payloads são removidos. Em ambos os modos, criação/consulta de análises expira tarefas com mais de 30 minutos; exige reenvio explícito, sem aprovação nem repetição silenciosa. Não é um sistema de leases/heartbeat nem cancela trabalho já em execução. Timeout do Celery limita uma tarefa a 360 s; a indisponibilidade do LLM interrompe as tentativas após o primeiro erro.

## Persistência e dados

Tabela `scans`: UUID, nome do projeto, estado, timestamps, payload temporário JSON, resultado JSON, erro sanitizado e indicador demo. O esquema é inicializado por SQLAlchemy `create_all`; não há migrações Alembic nesta versão. JSON facilita prototipagem, mas agregações de grande escala devem ser normalizadas/indexadas.

O painel carrega as 100 análises mais recentes; tendência considera até oito com o mesmo nome e a mesma classificação de demonstração. Nome de projeto não substitui uma entidade de projeto com ID em um produto multiusuário.

## Escala

```bash
docker compose up -d --scale worker=3
```

Os workers compartilham banco e fila, cada um com concorrência 2. O gargalo de IA em CPU deve ser medido antes de aumentar paralelismo. A aplicação atual possui chave única, limites modestos e ausência de autorização por usuário; escala operacional não implica isolamento entre organizações.

## Fronteiras de confiança

Código enviado é dado não confiável. Não há checkout de URLs arbitrárias, execução, instalação de dependências do alvo ou extração em disco. A IA não recebe ferramentas. Trechos são incluídos como dados com instrução contra prompt injection; isso reduz risco, mas não garante obediência do modelo. Por isso a IA jamais rebaixa o gate nem aplica correções.

Os serviços internos não publicam portas; isso não equivale a uma política completa de egress. Em produção, restrinja rede, implemente TLS, identidade individual, RBAC, auditoria, retenção e criptografia. A conexão PostgreSQL interna não configura TLS neste Compose de laboratório.

## Decisões técnicas

- Python AST para a linguagem de maior cobertura; Tree-sitter para parsing consistente de outras três linguagens.
- Regras explícitas e evidência de fluxo, mantendo explicabilidade acadêmica.
- Semgrep é uma alternativa recomendada no enunciado, não uma dependência deste projeto. Bandit é usado como segunda verificação no CI da plataforma, sem misturar seus achados ao dashboard.
- FastAPI entrega API e arquivos estáticos; não é necessário um build Node para iniciar o projeto.
- IA opcional mantém análise determinística disponível sem baixar um LLM.

## Decisões e trade-offs

- **AST/Tree-sitter próprio:** dá evidências e regras didáticas nas quatro linguagens; exige modelagem explícita de APIs e tem menos cobertura que scanners maduros. Bandit verifica a implementação Python no CI.
- **Celery + Redis:** desacopla requisição e análise; PostgreSQL é o estado durável. O broker recebe apenas o ID; o código permanece temporariamente no banco até conclusão/falha.
- **IA como revisão:** saída validada pelo esquema, limitada a três achados, sem ferramentas nem execução de correções. Uma severidade sugerida menor nunca aprova o gate determinístico.
- **Modo local:** facilita avaliação no Windows, mas não comprova a implantação distribuída. SQLite + duas threads são apenas o modo de desenvolvimento. Use um processo de API nesse modo.
- **Frontend sem build:** HTML/CSS/JS e fontes locais reduzem instalação e acessos externos; resultados são escapados antes de entrar no DOM.
