# Validação da entrega 1.2

Executada em 07/10/2026, Python 3.12.14, Linux. Resultados e horários exatos em `docs/evidence/validation.json`.

| Verificação | Resultado |
|---|---|
| Pytest | 85 aprovados; um aviso de depreciação do TestClient, sem falhas |
| Laboratório vulnerável | 14 achados: 6 críticos, 7 altos, 1 médio; quatro linguagens; gate bloqueado |
| Controles corrigidos | 0 achados; quatro linguagens; gate aprovado |
| Autoanálise Sentinel | Gate aprovado no pacote Python |
| Bandit em backend/scripts | 0 achados médios/altos |
| JavaScript | `node --check web/app.js` aprovado |
| Benchmark rotulado | 36 casos, 20 TP, 12 TN, 0 FP, 4 FN; falsos negativos documentados |
| Interface | Chromium com API real: login, laboratório, filtro Java, taint, análise segura, exportação, histórico e consulta Ollama; desktop/mobile |
| Docker Compose | Configuração entregue e job de CI preparado; daemon Docker não está disponível neste ambiente |
| Ollama | Contrato válido/inválido e indisponibilidade testados; inferência com modelo real não executada aqui |
| GitHub Actions | Workflow entregue; execução remota e proteção da branch dependem do repositório do grupo |
| Windows | Bootstrap Python conferido; execução nativa dos arquivos .bat precisa ser verificada no Windows |

## Reproduzir

Execute `VALIDAR_TUDO.bat` no Windows ou, com dependências instaladas, `python scripts/validate.py`. Os resultados novos ficam em `docs/evidence-local/`, preservando as evidências de preparação.

Para a implantação distribuída: `docker compose up --build -d --wait`, seguido de `python scripts/smoke_compose.py`. O teste verifica os dois gates, quatro linguagens, fila Celery e exportação SARIF. Para inferência real com Ollama nativo, execute `python scripts/smoke_ai.py`; para Ollama dentro do Compose, solicite IA no painel e exporte o resultado.

O teste opcional de navegador está em `scripts/ui_browser_test.cjs`: instale Playwright, inicie a API com banco descartável e informe `UI_TEST_TOKEN` e `UI_TEST_URL`. Ele cria dados de teste. Não é dependência do uso normal.

## Precisão: o que os números significam

O corpus de 36 casos é sintético e autoral, não independente. Cada caso mede presença/ausência de uma regra-alvo. Há nove casos por linguagem, com cinco positivos detectados, três controles negativos e uma limitação entre funções não detectada.

- Precisão = TP/(TP+FP) = 20/20 = 100% neste corpus.
- Recall = TP/(TP+FN) = 20/24 = 83,3% neste corpus.
- Quatro falsos negativos são mantidos visíveis: falta de análise interprocedural.

Esses resultados não comprovam 100% de precisão em repositórios reais. `baseline_match` no JSON indica aderência ao comportamento documentado, inclusive limitações conhecidas; não significa que todos os casos vulneráveis foram detectados. A avaliação independente continua sendo uma evolução recomendada.

## Escopo dos testes

Parsing nas quatro linguagens; SQLi, comandos, XSS, credenciais, hash fraco, desserialização, SSRF e caminhos; origem/propagação/sink; branches, métodos, loops e destructuring básico; consultas parametrizadas; literal/comentário que parece código; máscara de credenciais; exportação; autenticação e cookie; origem HTTP; limite de corpo chunked; ZIP traversal/tamanho; persistência e remoção de payload; expiração de tarefa; JSON inválido da IA.

Os exemplos nunca são executados. A análise verifica estrutura; não realiza ataques nem comprova explorabilidade.

## Evidências

`pytest.xml`, `bandit.json`, `self-scan.json`, `safe.json`, `vulnerable.json`, `vulnerable.sarif`, `benchmark.json`, `validation.json` e `ui/browser.json`. Capturas do navegador ficam em `ui/`. Resultados antigos de interface/bootstrap mantidos em arquivos separados têm seus próprios contextos e não substituem a validação desta revisão.
