# Sentinel SAST — Relatório Técnico

**Projeto Integrador — Plataforma SAST & DevSecOps · Engenharia de Software 3º Ano · FIAP 2026**
Prof. M.Sc Oerton Fernandes · Documento de referência: FIAP_ENGSOFT_Projeto_SAST_OFVS_01082026

---

## 1. Sumário executivo

O Sentinel SAST é uma plataforma de análise estática de código-fonte (Static Application Security Testing) que inspeciona o código **sem executá-lo**, identificando vulnerabilidades estruturais, credenciais expostas e falhas lógicas na raiz do desenvolvimento. A estratégia é *shift-left*: a segurança audita cada mudança no início do ciclo de vida do software, reduzindo o custo de correção e impedindo que falhas críticas alcancem produção.

Diferenciais da entrega:

- **Motor próprio de AST/Tree-sitter** com 9 famílias de regras (CWE mapeadas, OWASP Top 10 2021) em 4 linguagens: Python, JavaScript/JSX, TypeScript/TSX e Java.
- **Taint analysis intraprocedural** com evidência de fluxo origem → propagação → sink em cada achado.
- **IA local opcional (Ollama/Llama 3)** para revisão semântica, severidade sugerida e remediação em código — sem jamais rebaixar o Security Gate determinístico.
- **DevSecOps**: Security Gate no CLI e no GitHub Actions, bloqueando Pull Requests inseguros, com exportação JSON e SARIF 2.1.0.
- **Arquitetura de microsserviços**: FastAPI + PostgreSQL + Redis + workers Celery, conteinerizada com Docker Compose, limites de recurso, contêineres read-only e usuário não-root.

## 2. Arquitetura técnica (C4)

### Nível 1 — Contexto

O desenvolvedor/equipe fornece apenas código-fonte autorizado (colagem, arquivos ou ZIP). O Sentinel produz achados potenciais, relatórios e dashboard. No CI/CD, o CLI opera sem banco nem credencial; seu exit code representa a política de bloqueio.

### Nível 2 — Contêineres

```mermaid
flowchart TB
    U["Navegador"] --> A["FastAPI + frontend"]
    A --> P[("PostgreSQL")]
    A --> R[("Redis / broker")]
    R --> W["Workers Celery"]
    W --> E["Motor AST / Tree-sitter"]
    W --> L["Ollama local"]
    W --> P
    G["GitHub Actions / CLI"] --> E
```

Fluxo de uma análise: (1) API autentica e valida nomes, tamanho, UTF-8, quantidade e formato; (2) PostgreSQL registra a análise `queued` com payload temporário; (3) Redis recebe apenas o UUID da tarefa — o código não trafega no corpo da mensagem; (4) o worker faz transição condicional `queued → running` (idempotente contra entregas duplicadas); (5) os parsers constroem a árvore e as regras inspecionam estrutura e propagação; (6) se solicitada, a IA recebe até 3 achados mascarados e devolve JSON validado por Pydantic; (7) o worker grava o resultado, remove o payload e marca `completed`; (8) o frontend consulta o status e renderiza.

Estados: `queued`, `running`, `completed`, `failed`. Análises de mais de 30 minutos expiram com falha explícita — o sistema **falha fechado**: nenhuma pendência vira aprovação silenciosa.

### Isolamento e segurança operacional

- API exposta apenas em `127.0.0.1`; PostgreSQL, Redis e Ollama sem portas publicadas.
- Contêineres `read_only`, `cap_drop: ALL`, `no-new-privileges`, limites de memória e de PIDs.
- Chave de instalação gerada aleatoriamente; cookies HttpOnly/SameSite=strict; validação de origem; CSP restritiva; rate limiting no login (10/min por IP).
- ZIPs não são extraídos em disco; rejeição de path traversal, links simbólicos e zip bombs (limites: 100 arquivos, 200 KB/arquivo, 2 MB total, 500 entradas).
- Segredos literais são mascarados (`[REDACTED]`) em snippets, relatórios e prompts de IA; código integral é removido do banco ao concluir/falhar.

## 3. Motor de análise

### Parsers

| Linguagem | Tecnologia | Motivo |
|---|---|---|
| Python | `ast.parse` (stdlib) | AST nativa, maior cobertura |
| JavaScript/JSX | Tree-sitter | parsing rápido e tolerante |
| TypeScript/TSX | Tree-sitter | mesma gramática base |
| Java | Tree-sitter | estrutura de métodos/campos |

Expressões, chamadas e atribuições são visitadas como nós da árvore — regex auxilia apenas no reconhecimento de nomes/fontes, nunca substitui o parser. Erros de sintaxe geram diagnóstico e **bloqueiam o gate** (falha fechada).

### Regras (família → CWE → severidade)

| Regra | Título | CWE | Severidade |
|---|---|---|---|
| S001 | Segredo no código-fonte | CWE-798 | high |
| S002 | Execução dinâmica de código (eval/exec) | CWE-95 | critical |
| S003 | Injeção de SQL | CWE-89 | critical |
| S004 | Execução de comando insegura | CWE-78 | critical |
| S005 | Cross-site scripting (XSS) | CWE-79 | high |
| S006 | Hash criptográfico fraco (MD5/SHA-1) | CWE-327 | medium |
| S007 | Desserialização insegura | CWE-502 | high |
| S008 | Requisição com destino não confiável (SSRF) | CWE-918 | high |
| S009 | Caminho de arquivo não confiável | CWE-22 | high |

### Taint analysis

- Fontes reconhecidas: `request.args/form/json/data/GET/POST/query_params` e `input()` (Python); `req.query/body/params`, `location.search`, `document.location` (JS/TS); `request.getParameter/getHeader/getQueryString`, `System.getenv` (Java).
- Propagação entre atribuições e expressões no mesmo corpo de função; evidência com linha da origem, atribuições intermediárias e sink.
- Atribuição de valor seguro remove a contaminação; ramos condicionais unem fluxos conservadoramente; funções têm ambientes locais separados.
- Conversões numéricas explícitas (`int`, `parseInt`, `Integer.parseInt`…) interrompem fluxos — aproximação documentada, não sanitizador universal.

### IA local (Ollama/Llama 3)

A IA é **revisão, não decisão**: recebe o achado como dado não confiável (instrução contra prompt injection), responde exclusivamente em JSON validado por esquema Pydantic (severidade, explicação, remediação, código corrigido, possível falso positivo), no máximo 3 achados por análise, timeout de 90 s. Indisponibilidade é explícita — o sistema não inventa resposta, e a severidade sugerida pela IA nunca aprova o gate determinístico.

## 4. DevSecOps e Security Gates

- **CLI**: `python -m sentinel.cli <caminho> --threshold high --output r.json --sarif r.sarif`. Exit codes: `0` aprovado, `1` bloqueado, `2` erro operacional. Erro de parsing ou ausência de arquivos analisados bloqueia o gate.
- **GitHub Actions** (`.github/workflows/security.yml`): job `security` (pytest, benchmark rotulado, Bandit, gate da própria plataforma, contraprova segura/vulnerável, artefatos de relatório) e job `containers` (compose up + smoke test de API/Redis/worker/PostgreSQL).
- **SARIF 2.1.0** para integração com code scanning; **JSON** para o dashboard e histórico.

## 5. Validação

| Verificação | Resultado |
|---|---|
| Pytest (ambiente de desenvolvimento) | 85 aprovados |
| Laboratório vulnerável (4 linguagens) | 14 achados: 6 críticos, 7 altos, 1 médio — gate bloqueado |
| Controles corrigidos (4 linguagens) | 0 achados — gate aprovado |
| Gate Python (reexecutado nesta entrega) | vulnerável: exit 1 (bloqueado, 7 achados, risco 100) · seguro: exit 0 (aprovado) |
| Bandit na plataforma | 0 achados médios/altos |
| Benchmark rotulado (36 casos) | 20 TP, 12 TN, 0 FP, 4 FN — precisão 100%, recall 83,3% no corpus autoral |
| Interface | Chromium desktop/mobile com API real: login, laboratório, filtros, taint, exportação, histórico |

**Limites declarados** (transparência de cobertura, `docs/COBERTURA.md`): análise intraprocedural (sem resumos entre funções ou entre arquivos); S002/S005 não implementadas em Java; S007 não implementada em JS/TS; loops aproximados em uma passagem; parâmetros de função não são fontes automáticas. Zero achados significa que nenhuma regra reconhecida encontrou evidência no escopo analisado — não que o código esteja seguro.

## 6. Rastreabilidade ao enunciado

| Exigência | Evidência |
|---|---|
| CP1: arquitetura C4 + Docker Compose | `docs/ARQUITETURA.md`, `compose.yaml`, `Dockerfile` |
| CP1: parser funcional + 3 violações | AST/Tree-sitter; S001, S002, S003 + 6 famílias |
| Multilinguagem | 4 linguagens; 36 casos rotulados em `benchmark/cases.json` |
| CP2: taint analysis | `sentinel/engine.py`; rastros nos achados e testes |
| CP2: LLM local + remediação | `sentinel/ai.py`; Ollama; JSON schema; código sugerido |
| CP3: dashboard executivo | `web/` — severidade, tendência, top arquivos críticos, detalhe por linha |
| CP3: Security Gate no CI/CD | CLI + workflow `security.yml` + job `containers` |
| Relatórios | JSON e SARIF 2.1.0 |
| Documentação e defesa | README, guias de início, este relatório e roteiro abaixo |

## 7. Roteiro de defesa (8–10 minutos)

1. **Problema e objetivo (1 min)** — vulnerabilidades descobertas cedo custam menos; SAST inspeciona sem executar; a ferramenta sinaliza risco potencial.
2. **Arquitetura (1 min)** — C4, API, PostgreSQL, Redis, workers, Ollama, isolamento de portas; `docker compose ps`.
3. **Parser e regras (2 min)** — laboratório ao vivo com 4 linguagens; abrir S001/S002/S003; por que AST reduz ruído de comentários e strings.
4. **Taint (1 min)** — em SQLi, seguir request → variável → consulta → execute; mostrar a consulta parametrizada aprovada.
5. **IA (1 min)** — executar o LLM local; severidade sugerida e trecho corrigido; o gate não é rebaixado automaticamente.
6. **Dashboard (1 min)** — cores, fórmula de risco, tendência registrada, top arquivos, relatórios.
7. **DevSecOps (1 min)** — PR com código vulnerável falha o check obrigatório; correção aprovada; artefato SARIF.
8. **Validação e limites (1 min)** — testes, corpus pequeno, sem análise interprocedural/RBAC; transparência como postura de engenharia.

**Perguntas prováveis** — por que não apenas regex? (estrutura vem dos parsers) · por que a IA não decide sozinha? (alucinação/prompt injection; JSON validado não garante correção semântica) · zero achados é seguro? (não; cobertura e ambiente importam) · como escala? (`--scale worker=3`, gargalo de IA em CPU deve ser medido) · qual o diferencial? (evidência de fluxo, 4 parsers, remediação local, transparência de cobertura, gate que bloqueia também análises incompletas).

## 8. Como executar

```bash
# Docker (recomendado — comprova a arquitetura distribuída)
python scripts/setup.py          # gera .env com segredos
docker compose up --build -d     # http://localhost:8000
docker compose --profile ai up -d && docker compose exec ollama ollama pull llama3.2:3b

# Desenvolvimento local (SQLite + threads)
pip install -r requirements-dev.txt
python scripts/run_local.py      # http://localhost:8765

# Testes e gates
python -m pytest -q
python -m sentinel.cli examples/vulnerable --threshold high   # exit 1 = bloqueado
python -m sentinel.cli examples/safe --threshold high         # exit 0 = aprovado
```

## 9. Conclusão

A entrega demonstra um ciclo DevSecOps completo e funcional: parsing multi-linguagem por AST, detecção determinística com evidência de fluxo, IA local como assistente de remediação sob controle determinístico, gate que bloqueia CI/CD, dashboard executivo e documentação honesta de cobertura e limites. A plataforma é uma base acadêmica — não substitui Semgrep/CodeQL comerciais — e a postura adotada (falhar fechado, evidência auditável, limites declarados) é o próprio padrão de engenharia segura que o projeto ensina.
