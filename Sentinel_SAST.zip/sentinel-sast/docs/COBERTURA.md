# Cobertura e limites do motor

Parsing multilinguagem não significa cobertura semântica completa de cada linguagem. As regras abaixo são padrões reconhecidos, e não um compilador com resolução de tipos.

| Regra | Python | JavaScript / TypeScript | Java |
|---|---|---|---|
| S001 credencial literal | Assign/AnnAssign com nome sensível | variable_declarator/assignment_expression e propriedades literais de objetos | campo/variável literal |
| S002 avaliação dinâmica | eval/exec, aliases de import | eval, Function, window.eval | não implementada |
| S003 SQLi | execute/executemany/raw, primeiro argumento contaminado | query/execute, primeiro argumento contaminado | executeQuery/executeUpdate/execute, primeiro argumento contaminado |
| S004 comando | os.system/popen; subprocess com shell=True | exec/execSync e imports Node reconhecidos; RegExp.exec não é tratado como shell | método exec com primeiro argumento contaminado |
| S005 XSS | render_template_string/Markup contaminado | innerHTML/outerHTML dinâmico; send/write contaminado | não implementada |
| S006 hash fraco | hashlib.md5/sha1 | createHash('md5'/'sha1') | getInstance('MD5'/'SHA-1') |
| S007 desserialização | pickle.load(s), marshal.loads, yaml.unsafe_load | não implementada | readObject |
| S008 SSRF | requests/httpx get/post, urllib.request.urlopen | fetch/axios get/post | URL contaminada em openConnection/openStream |
| S009 caminho | open com caminho contaminado | readFile/Sync, writeFileSync | FileInputStream/OutputStream, FileReader/Writer, RandomAccessFile e métodos Files reconhecidos |

Fontes reconhecidas incluem Python `request.args/form/json/values/data/GET/POST/query_params`, `input()`; JS/TS `req.query/body/params`, `location.search/hash`, `document.location`; Java `request.getParameter/getHeader/getQueryString`, `System.getenv`. O nome do objeto importa. Imports de request do Flask com alias são reconhecidos; aliases arbitrários de objetos não têm resolução completa. JS/TS inclui destructuring simples de fontes conhecidas; propriedades são aproximadas conservadoramente.

## Rastreamento

- Propagação entre atribuições e expressões no mesmo corpo de função.
- Evidência com linha da origem, atribuições intermediárias e sink.
- Atribuição de valor seguro remove a contaminação em sequência linear.
- Ramos condicionais são unidos conservadoramente. Loops têm aproximação de uma passagem, sem ponto fixo de CFG completo.
- Funções têm ambientes locais separados para evitar vazamento de variáveis entre funções irmãs.
- Não há resumos entre funções, análise de chamadas entre arquivos, heap/alias analysis ou resolução de bibliotecas e tipos.
- Python resolve aliases de imports de funções reconhecidas, com isolamento dos aliases locais entre funções; shadowing e binding dinâmico completos não são modelados.
- Parâmetros de funções não são automaticamente marcados como fontes; precisa haver uma fonte reconhecida.
- Não são rastreados todos os kwargs, iteradores, comprehension bindings, padrões aninhados de destructuring ou campos de objetos. Tuplas simples em Python e destructuring básico em JS/TS são suportados.
- Conversões numéricas explícitas reconhecidas (`int`, `float`, `parseInt`, `parseFloat`, `Number`, `Integer.parseInt`) interrompem os fluxos atuais. Esse modelo é uma aproximação; não constitui sanitizador universal.

## Precisão

Regras S001/S002/S004/S006/S007 podem disparar estruturalmente mesmo sem origem controlada por usuário. MD5 pode ser checksum, `exec` pode ser método de outra biblioteca, `res.send` pode usar tipo de conteúdo seguro e uma credencial pode ser fixture. Por isso confiança, evidência e revisão humana aparecem no detalhe.

Consultas parametrizadas reconhecidas não são marcadas apenas por terem um parâmetro externo: a contaminação deve atingir o primeiro argumento (texto SQL). Isso reduz falsos positivos nos controles de teste, mas abstrações de bancos não reconhecidas podem passar despercebidas.

Erros de sintaxe geram diagnóstico e bloqueiam o gate; não são ocultados como resultado seguro. Extensões não suportadas são ignoradas ou identificadas como unsupported em análise direta. Repositórios grandes devem ser particionados para respeitar os limites desta versão.

## Métricas

Índice de risco heurístico: `min(100, 30*critical + 15*high + 5*medium + low)`. Mede concentração ponderada de achados, não CVSS, probabilidade de invasão ou percentual de segurança. O gate considera severidade, erros de parsing e presença de arquivos válidos.

CWE representa a classe de fraqueza. Referência OWASP é explicitamente a edição 2021. Não atribuímos CVEs de produtos conhecidos a código arbitrário; isso exigiria identificação de versão e análise de dependências, fora do escopo.

## Avaliação rotulada adicional

`benchmark/cases.json` contém 36 casos sintéticos: nove por linguagem, incluindo três controles negativos e uma limitação interprocedural por linguagem. `python scripts/benchmark.py` calcula TP, FP, FN, TN, precisão e recall por caso/regra-alvo. Na execução registrada: 20 TP, 12 TN, 0 FP e 4 FN; precisão 100% e recall 83,3% **apenas nesse corpus autoral**. Não mede cobertura universal, todas as regras em todas as linguagens nem desempenho independente. Os falsos negativos ficam visíveis no JSON.
