# Entrega e defesa

## Rastreabilidade ao documento do professor

| Exigência | Evidência entregue | Verificação restante |
|---|---|---|
| CP1: arquitetura C4 e Compose | ARQUITETURA.md, compose.yaml, Dockerfile | Subir contêineres e capturar evidência |
| CP1: parser funcional e três violações | AST/Tree-sitter; S001, S002, S003 e outras seis famílias | Demonstração ao vivo |
| Multilinguagem | Python, JavaScript, TypeScript, Java; 36 casos rotulados | Cobertura e quatro falsos negativos explicitados |
| CP2: taint analysis | engine.py, rastros nos achados e testes | Discutir limites intraprocedurais |
| CP2: LLM local e remediação | ai.py, Ollama, JSON schema e código sugerido | Executar modelo real e revisar resposta |
| CP3: dashboard | web/ com severidade, tendência, arquivos críticos e detalhe | Inspeção visual no navegador local |
| CP3: gate no CI/CD | CLI, workflow security e job containers | Ativar workflow e proteção da branch |
| Relatórios | JSON e SARIF | Guardar artefatos da execução final |
| Documentação e defesa | README, guias, RELATORIO_TECNICO.pdf e roteiro abaixo | Completar integrantes e divisão real de tarefas |

## Checklist antes de enviar em 20/10/2026

- [ ] Preencher nomes e RMs reais do grupo no arquivo EQUIPE.md; confirmar integrantes com o professor (PDF menciona 4–5).
- [ ] Executar Docker Compose e `scripts/smoke_compose.py`.
- [x] Preparação: 85 testes passaram; evidências em docs/evidence. Reproduza localmente com VALIDAR_TUDO.bat.
- [x] Preparação: dashboard conferido em Chromium desktop/mobile com API real. Repita no computador de apresentação.
- [ ] Analisar um repositório autorizado diferente das fixtures e registrar falsos positivos/falsos negativos.
- [ ] Baixar o modelo local, fazer uma varredura com IA e revisar criticamente a correção sugerida.
- [ ] Criar o repositório GitHub sem `.env`, bancos ou código de terceiros sem autorização.
- [ ] Confirmar os jobs `security` e `containers` verdes no GitHub Actions.
- [ ] Configurar proteção de `main` exigindo os checks; demonstrar um PR vulnerável bloqueado.
- [ ] Guardar prints do gate bloqueado, gate aprovado, fluxo de dados e revisão real de IA.
- [ ] Confirmar com o professor se deseja também vídeo, slides, PDF ou algum formato de submissão adicional.

## Roteiro de defesa (8–10 minutos)

1. **Problema e objetivo — 1 min.** Vulnerabilidades descobertas cedo custam menos retrabalho; SAST inspeciona sem executar. Explique que a ferramenta sinaliza risco potencial.
2. **Arquitetura — 1 min.** Mostre C4, API, PostgreSQL, Redis, workers, Ollama e isolamento de portas. Mostre `docker compose ps`.
3. **Parser e regras — 2 min.** Rode o laboratório; mostre quatro linguagens. Abra S001, S002 e S003. Explique por que AST reduz ruído de comentários e strings.
4. **Taint — 1 min.** Em SQLi, siga request → variável → consulta → execute. Mostre consulta parametrizada correspondente e a aprovação.
5. **IA — 1 min.** Execute o LLM local, apresente severidade sugerida e trecho corrigido, e explique que o gate não é rebaixado automaticamente.
6. **Dashboard — 1 min.** Explique cores, fórmula de risco, dados de tendência efetivamente registrados, top arquivos e relatórios.
7. **DevSecOps — 1 min.** Mostre um PR com código vulnerável, falha do check obrigatório e artefato SARIF; em seguida, a correção aprovada.
8. **Validação e limites — 1 min.** Apresente os testes e o corpus pequeno. Aponte que não há análise interprocedural, RBAC ou garantia de detecção completa.

## Perguntas prováveis

**Por que não apenas regex?** A estrutura é obtida por parsers; expressões, chamadas e atribuições são visitadas como nós. Regex auxilia reconhecimento de nomes/fontes em nós, não substitui o parser.

**Por que o modelo não decide sozinho?** Respostas podem variar, alucinar ou obedecer conteúdo malicioso do código. O JSON é validado, mas a validade estrutural não garante correção semântica. Política determinística e revisão humana permanecem.

**Zero achados significa seguro?** Não. Significa que nenhuma regra reconhecida encontrou evidência no escopo analisado. Cobertura e ambiente importam.

**Como escala?** Workers separados consomem IDs do Redis e gravam no PostgreSQL. É possível aumentar réplicas; latência da IA, quotas e persistência precisam ser medidas.

**Qual o diferencial?** Evidência de fluxo ligada ao achado, quatro parsers, remediação contextual local, transparência de cobertura e gate que bloqueia também análises incompletas.

## Evoluções prioritárias

1. Corpus independente e comparação com Bandit/Semgrep para calibrar precisão e recall.
2. CFG completo, análise interprocedural e modelagem de frameworks.
3. Migrações Alembic, leases/heartbeat com retomada de jobs e observabilidade. A versão atual expira pendências em vez de retomá-las.
4. Identidade individual, RBAC e isolamento de projetos para uso fora do laboratório.
