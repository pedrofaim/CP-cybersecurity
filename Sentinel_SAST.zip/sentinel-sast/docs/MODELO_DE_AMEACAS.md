# Modelo de ameaças e decisões de segurança

Escopo: instalação acadêmica local, uma chave compartilhada, repositórios autorizados e arquivos potencialmente maliciosos. Não é uma plataforma SaaS multiusuário.

| Ativo / ameaça | Controle implementado | Limitação residual |
|---|---|---|
| Código enviado executar no servidor | Somente parsers; nenhum eval/exec/import do arquivo analisado | Parsers são dependências que devem ser atualizadas |
| ZIP traversal / bomba de expansão | Caminhos relativos, rejeição de symlink, limites comprimidos e expandidos, sem extração em disco | Quotas de CPU não existem por usuário |
| Sobrecarga por body chunked | Limite real de 3 MB antes de JSON/multipart | Reverse proxy e quotas globais são necessários em produção |
| Leitura de resultados por terceiro | Bearer ou cookie HttpOnly/HMAC; comparação de segredo; API local | Chave compartilhada, sem RBAC, rotação manual e sem auditoria por pessoa |
| XSS no dashboard | Escape de campos, CSP e fontes locais | Sugestões precisam de revisão contextual; CSP permite estilos inline |
| CSRF | SameSite Strict e validação de Origin nas mutações | Exposição fora de localhost requer TLS e revisão da topologia |
| Vazamento de credenciais | Redação de literais detectados, payload apagado ao terminar/falhar | Código fica temporariamente no banco; a máscara não reconhece todo segredo/PII |
| Prompt injection no código | Código como dado não confiável, sem ferramentas, JSON validado e gate independente | Instruções do prompt não garantem imunidade; correção não é aplicada automaticamente |
| Worker cai e resultado parece seguro | Sem resultado = sem aprovação; expiração após 30 min; falha no reinício local | Não há leases/heartbeat nem retomada automática; reenvio manual |
| Biblioteca de terceiros vulnerável | Versões diretas fixadas; Bandit e gates no CI | Não há scanner SCA/CVE de dependências nesta versão |

O limite de oito tarefas pendentes é uma proteção simples, não uma quota transacional distribuída. Aumentar réplicas da API exige controle de admissão atômico. Só API publica porta de localhost no Compose; os demais serviços compartilham a rede interna do projeto, sem portas publicadas. Essa rede não é uma política completa de bloqueio de saída.

As sugestões de correção devem ser revistas e testadas pelo grupo. Não use os resultados como certificação de segurança, nem analise propriedade intelectual sem autorização.
