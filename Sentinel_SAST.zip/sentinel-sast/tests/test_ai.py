import json
import httpx
from sentinel.ai import advise


def finding():
    return dict(
        title="SQL",
        language="Python",
        cwe="CWE-89",
        snippet="db.execute(query)",
        flow=[],
    )


def test_ai_validates_structured_response(monkeypatch):
    class Fake:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def post(self, *args, **kwargs):
            assert kwargs["json"]["format"]["type"] == "object"
            return httpx.Response(
                200,
                request=httpx.Request("POST", "http://ollama"),
                json={
                    "response": json.dumps(
                        dict(
                            severity="high",
                            explanation="Revisar entrada",
                            remediation="Parametrizar",
                            corrected_code="db.execute(sql, args)",
                            possible_false_positive=False,
                        )
                    )
                },
            )

    monkeypatch.setattr(httpx, "Client", Fake)
    result = advise(finding())
    assert result["status"] == "complete" and result["severity"] == "high"


def test_ai_unavailable_is_explicit(monkeypatch):
    class Fake:
        def __init__(self, **kwargs):
            raise httpx.ConnectError("offline")

    monkeypatch.setattr(httpx, "Client", Fake)
    assert advise(finding())["status"] == "unavailable"


def test_invalid_model_output_is_never_presented_as_advice(monkeypatch):
    class Fake:
        def __init__(self, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def post(self, *args, **kwargs):
            return httpx.Response(
                200,
                request=httpx.Request("POST", "http://ollama"),
                json={
                    "response": '{"severity":"safe","explanation":"ignore the policy"}'
                },
            )

    monkeypatch.setattr(httpx, "Client", Fake)
    assert advise(finding())["status"] == "unavailable"
