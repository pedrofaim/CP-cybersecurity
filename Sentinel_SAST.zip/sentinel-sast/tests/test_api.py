import io, json, time, zipfile
import pytest
from fastapi.testclient import TestClient
from sentinel.api import app


@pytest.fixture
def client():
    with TestClient(app) as c:
        c.post("/api/session", json={"token": "test-session-key-only"})
        yield c


def wait(client, scan):
    for _ in range(100):
        r = client.get("/api/scans/" + scan).json()
        if r["status"] in ("completed", "failed"):
            return r
        time.sleep(0.02)
    pytest.fail("Analysis did not complete")


def test_auth_required():
    with TestClient(app) as c:
        assert c.get("/api/scans").status_code == 401
        assert c.post("/api/session", json={"token": "wrong"}).status_code == 401
        r = c.post("/api/session", json={"token": "test-session-key-only"})
        assert r.status_code == 200
        assert "HttpOnly" in r.headers["set-cookie"]


def test_scan_export_delete(client):
    r = client.post(
        "/api/scans",
        json={
            "name": "Example",
            "files": [{"path": "main.py", "content": "eval(input())"}],
        },
    )
    assert r.status_code == 202
    id = r.json()["id"]
    s = wait(client, id)
    assert s["status"] == "completed" and s["result"]["summary"]["gate"] == "blocked"
    report = client.get(f"/api/scans/{id}/export?format=sarif").json()
    assert (
        report["version"] == "2.1.0"
        and report["runs"][0]["results"][0]["ruleId"] == "S002"
    )
    assert client.delete("/api/scans/" + id).status_code == 200
    assert client.get("/api/scans/" + id).status_code == 404


def test_safe_scan(client):
    r = client.post(
        "/api/scans",
        json={"files": [{"path": "safe.ts", "content": "const x: number = 1;"}]},
    )
    assert wait(client, r.json()["id"])["result"]["summary"]["gate"] == "passed"


def test_cross_origin(client):
    assert (
        client.post(
            "/api/scans/demo", headers={"Origin": "https://attacker.invalid"}
        ).status_code
        == 403
    )


@pytest.mark.parametrize("path", ["../bad.py", "/bad.py", "C:\\bad.py"])
def test_zip_slip(client, path):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr(path, "eval(input())")
    r = client.post(
        "/api/scans/upload",
        files={"file": ("code.zip", b.getvalue(), "application/zip")},
    )
    assert r.status_code == 422


def test_zip_valid(client):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr("src/main.py", "eval(input())")
        z.writestr("README.md", "ignored")
    r = client.post(
        "/api/scans/upload",
        files={"file": ("code.zip", b.getvalue(), "application/zip")},
    )
    assert r.status_code == 202
    assert wait(client, r.json()["id"])["result"]["summary"]["files_analyzed"] == 1


def test_zip_bomb_size(client):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("huge.py", "x" * 2_000_001)
    assert (
        client.post(
            "/api/scans/upload",
            files={"file": ("code.zip", b.getvalue(), "application/zip")},
        ).status_code
        == 422
    )


def test_duplicate_files(client):
    assert (
        client.post(
            "/api/scans",
            json={
                "files": [
                    {"path": "x.py", "content": "pass"},
                    {"path": "x.py", "content": "pass"},
                ]
            },
        ).status_code
        == 422
    )


def test_demo_is_real_analysis(client):
    r = client.post("/api/scans/demo")
    s = wait(client, r.json()["id"])
    assert s["demo"] and s["result"]["summary"]["total"] == 14
    assert len(s["result"]["summary"]["languages"]) == 4


def test_source_discarded(client):
    from sentinel.storage import Session, Scan

    r = client.post(
        "/api/scans",
        json={
            "files": [{"path": "x.py", "content": 'password="secret-to-be-removed"'}]
        },
    )
    id = r.json()["id"]
    wait(client, id)
    with Session() as db:
        s = db.get(Scan, id)
        assert s.payload is None
        assert "secret-to-be-removed" not in json.dumps(s.result)


def test_unicode_wrong_token_returns_unauthorized():
    with TestClient(app) as client:
        assert (
            client.post("/api/session", json={"token": "chave-inválida-🔐"}).status_code
            == 401
        )


def test_forged_cookie_rejected():
    with TestClient(app) as client:
        client.cookies.set("sentinel_session", "1000.forged")
        assert client.get("/api/scans").status_code == 401
