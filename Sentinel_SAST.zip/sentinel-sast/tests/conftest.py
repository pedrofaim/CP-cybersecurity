import os, tempfile

os.environ["DATABASE_URL"] = "sqlite:///" + tempfile.mktemp(
    prefix="sentinel-test-", suffix=".db"
)
os.environ["API_TOKEN"] = "test-session-key-only"
os.environ["QUEUE_MODE"] = "local"
