"""Regression cases found during review; none of the input programs are executed."""

import asyncio
import json
from datetime import datetime, timedelta, timezone
import pytest
from sentinel.engine import analyze_file, analyze
from sentinel.body_limit import BodyLimitMiddleware
from sentinel.storage import Session, Scan, expire_scans, init_db


@pytest.mark.parametrize(
    "path,code,expected",
    [
        (
            "app.py",
            'x, y = request.args.get("id"), "fixed"\ndb.execute("SELECT " + x)',
            "S003",
        ),
        (
            "app.py",
            'for value in request.args.getlist("id"):\n db.execute("SELECT " + value)',
            "S003",
        ),
        ("app.py", 'import os\nwith open("file") as f:\n os.system("date")', "S004"),
        ("app.js", 'const { id } = req.query; db.query("SELECT " + id);', "S003"),
        (
            "app.ts",
            'const { id: externalId } = req.query; db.query("SELECT " + externalId);',
            "S003",
        ),
        (
            "app.js",
            'for (let x=req.query.id; condition; x="fixed") { db.query(x); }',
            "S003",
        ),
        (
            "app.js",
            'import * as process from "node:child_process"; process.exec(req.query.cmd);',
            "S004",
        ),
        (
            "app.ts",
            'import { exec as execute } from "node:child_process"; execute(req.query.cmd);',
            "S004",
        ),
        ("app.js", 'const credentials = { password: "only-a-test-value" };', "S001"),
        (
            "App.java",
            'class App { void run() { String path = request.getParameter("file"); new FileInputStream(path); } }',
            "S009",
        ),
        (
            "App.java",
            'class App { void run() { String path = request.getParameter("file"); Files.readString(Paths.get(path)); } }',
            "S009",
        ),
        (
            "App.java",
            'class App { void run() { URL remote = new URL(request.getParameter("url")); remote.openConnection(); } }',
            "S008",
        ),
        (
            "App.java",
            'class App { void run() { stmt.executeQuery(request.getHeader("X-Query")); } }',
            "S003",
        ),
    ],
)
def test_expanded_coverage(path, code, expected):
    findings, detail = analyze_file(path, code)
    assert detail["status"] == "analyzed"
    assert expected in {f["rule_id"] for f in findings}


@pytest.mark.parametrize(
    "path,code",
    [
        ("app.js", "const expression = /abc/; expression.exec(req.query.value);"),
        (
            "app.js",
            "class App { first() { const id=req.query.id; } second() { db.query(id); } }",
        ),
        (
            "app.py",
            'def first():\n from os import system as run\n run("date")\ndef second():\n run("date")',
        ),
        ("App.java", 'class App { void run() { new FileInputStream("fixed.txt"); } }'),
        (
            "App.java",
            'class App { void run() { URL remote = new URL("https://example.invalid"); remote.openConnection(); } }',
        ),
    ],
)
def test_controls(path, code):
    findings, _ = analyze_file(path, code)
    if path.endswith(".py"):
        assert [(f["rule_id"], f["line"]) for f in findings] == [("S004", 3)]
    else:
        assert not findings


def test_object_secret_is_removed_from_all_evidence():
    findings, _ = analyze_file(
        "app.js",
        'const config = {password: "only-a-test-value"};\neval(req.body.code);',
    )
    assert "only-a-test-value" not in json.dumps(findings)


def test_deep_tree_fails_closed():
    result = analyze(
        [{"path": "deep.js", "content": "const x = " + "a+".join(["b"] * 1500) + ";"}]
    )
    assert result["summary"]["gate"] == "blocked"
    assert result["summary"]["parse_errors"] == 1


def test_chunked_upload_limit_without_content_length():
    async def scenario():
        called = False
        sent = []
        messages = iter(
            [
                {"type": "http.request", "body": b"abcd", "more_body": True},
                {"type": "http.request", "body": b"efgh", "more_body": False},
            ]
        )

        async def receive():
            return next(messages)

        async def send(message):
            sent.append(message)

        async def downstream(scope, receive, send):
            nonlocal called
            called = True

        await BodyLimitMiddleware(downstream, max_bytes=6)(
            {"type": "http", "method": "POST"}, receive, send
        )
        assert not called
        assert sent[0]["status"] == 413

    asyncio.run(scenario())


def test_expired_job_is_failed_and_input_removed():
    init_db()
    scan_id = "test-expiration"
    with Session() as db:
        previous = db.get(Scan, scan_id)
        if previous:
            db.delete(previous)
            db.commit()
        db.add(
            Scan(
                id=scan_id,
                name="Interrupted test",
                status="running",
                created_at=datetime.now(timezone.utc) - timedelta(minutes=31),
                payload={"files": []},
            )
        )
        db.commit()
    expire_scans()
    with Session() as db:
        scan = db.get(Scan, scan_id)
        assert (
            scan.status == "failed"
            and scan.payload is None
            and scan.finished_at is not None
        )
        db.delete(scan)
        db.commit()


def test_imported_request_alias_is_a_source():
    findings, _ = analyze_file(
        "app.py",
        'from flask import request as incoming\nx=incoming.args.get("query")\ndb.execute(x)',
    )
    assert any(f["rule_id"] == "S003" for f in findings)


def test_long_trace_preserves_original_source():
    code = (
        'x0=request.args.get("query")\n'
        + "\n".join(f"x{i}=x{i - 1}" for i in range(1, 20))
        + "\ndb.execute(x19)"
    )
    finding = analyze_file("app.py", code)[0][0]
    assert finding["flow"][0]["kind"] == "source" and finding["flow"][0]["line"] == 1
    assert finding["flow"][-1]["kind"] == "sink"
    assert len(finding["flow"]) <= 13
