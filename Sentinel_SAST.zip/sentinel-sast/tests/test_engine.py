import json
import subprocess
import sys
from pathlib import Path
import pytest
from sentinel.engine import analyze, analyze_file

ROOT = Path(__file__).resolve().parents[1]


def rules(path, code):
    return {f["rule_id"] for f in analyze_file(path, code)[0]}


@pytest.mark.parametrize(
    "path,source,rule",
    [
        ("a.py", 'PASSWORD = "test-secret-123"', "S001"),
        ("a.py", "eval(input())", "S002"),
        (
            "a.py",
            'from flask import request\nx=request.args.get("x")\nsql="SELECT "+x\ndb.execute(sql)',
            "S003",
        ),
        ("a.py", 'import os as operating\noperating.system("date")', "S004"),
        ("a.py", 'import hashlib\nhashlib.md5(b"x")', "S006"),
        ("a.py", "import pickle\npickle.loads(raw)", "S007"),
        ("a.py", 'import requests\nrequests.get(request.args.get("url"))', "S008"),
        ("a.py", 'open(request.args.get("file"))', "S009"),
        ("a.js", "eval(req.body.code);", "S002"),
        (
            "a.js",
            'const x = req.query.id; const sql = "SELECT " + x; db.query(sql);',
            "S003",
        ),
        ("a.ts", "const x: string = req.query.html; el.innerHTML = x;", "S005"),
        ("a.ts", "fetch(req.query.url);", "S008"),
        (
            "A.java",
            'class A { void m() { String x = request.getParameter("q"); stmt.executeQuery("SELECT "+x); } }',
            "S003",
        ),
        ("A.java", 'class A { String password = "demo-secret"; }', "S001"),
        (
            "A.java",
            'class A { void m() { MessageDigest.getInstance("MD5"); } }',
            "S006",
        ),
    ],
)
def test_rules(path, source, rule):
    assert rule in rules(path, source)


@pytest.mark.parametrize(
    "path,source",
    [
        ("a.py", '# eval(input())\ntext = "eval(input())"'),
        ("a.js", '// eval(req.query.x)\nconst text="eval(input())";'),
        (
            "a.py",
            'db.execute("SELECT * FROM users WHERE id=%s", (request.args.get("id"),))',
        ),
        ("a.js", 'db.query("SELECT * FROM users WHERE id=?", [req.query.id]);'),
        ("a.py", 'x=request.args.get("x")\nx="fixed"\ndb.execute(x)'),
        ("a.js", 'let x=req.query.x; x="fixed"; db.query(x);'),
        ("a.py", 'x=int(request.args.get("x"))\ndb.execute("SELECT "+str(x))'),
        ("a.js", 'const x=parseInt(req.query.x); db.query("SELECT "+x);'),
        ("a.ts", "const x: string=req.query.x; el.textContent=x;"),
        ("a.py", 'def a():\n x=request.args.get("x")\ndef b():\n db.execute(x)'),
        ("a.js", "function a(){ const x=req.query.x; } function b(){ db.query(x); }"),
    ],
)
def test_negative_controls(path, source):
    assert not rules(path, source)


@pytest.mark.parametrize(
    "path,source",
    [
        ("a.py", 'x="safe"\nif condition:\n x=request.args.get("x")\ndb.execute(x)'),
        ("a.js", 'let x="safe"; if (condition) { x=req.query.x; } db.query(x);'),
    ],
)
def test_branch_conservative_join(path, source):
    assert "S003" in rules(path, source)


@pytest.mark.parametrize(
    "path,source",
    [
        ("a.py", "def broken(:"),
        ("a.js", "function {"),
        ("a.ts", "const a: = ;"),
        ("A.java", "class {"),
    ],
)
def test_syntax_errors_block(path, source):
    r = analyze([{"path": path, "content": source}])
    assert r["summary"]["gate"] == "blocked"
    assert r["summary"]["parse_errors"] == 1


def test_trace_and_redaction():
    findings, _ = analyze_file(
        "a.py",
        'password="never-persist-this"\nx=request.args.get("x")\nsql="SELECT "+x\ndb.execute(sql)',
    )
    assert "never-persist-this" not in json.dumps(findings)
    sql = next(f for f in findings if f["rule_id"] == "S003")
    assert sql["flow"][0]["kind"] == "source" and sql["flow"][-1]["kind"] == "sink"
    assert any(s["kind"] == "propagation" for s in sql["flow"])


def test_threshold():
    r = analyze(
        [{"path": "a.py", "content": 'import hashlib\nhashlib.md5(b"x")'}],
        threshold="high",
    )
    assert r["summary"]["gate"] == "passed"
    r = analyze(
        [{"path": "a.py", "content": 'import hashlib\nhashlib.md5(b"x")'}],
        threshold="medium",
    )
    assert r["summary"]["gate"] == "blocked"


def test_empty_blocks():
    assert analyze([])["summary"]["gate"] == "blocked"


@pytest.mark.parametrize("path", ["../x.py", "/x.py", "C:\\x.py"])
def test_path_validation(path):
    with pytest.raises(ValueError):
        analyze_file(path, "pass")


def test_reference_corpus(tmp_path):
    for folder, expected in [("safe", 0), ("vulnerable", 1)]:
        output = tmp_path / (folder + ".json")
        run = subprocess.run(
            [
                sys.executable,
                "-m",
                "sentinel.cli",
                str(ROOT / "examples" / folder),
                "--output",
                str(output),
            ],
            capture_output=True,
        )
        assert run.returncode == expected, run.stderr
        result = json.loads(output.read_text())
        assert len(result["summary"]["languages"]) == 4
        if folder == "vulnerable":
            assert result["summary"]["total"] == 14


@pytest.mark.parametrize(
    "path,source",
    [
        ("a.py", 'x = format("request.args")\ndb.execute(x)'),
        ("a.js", 'const x = format("req.query.x"); db.query(x);'),
    ],
)
def test_source_words_inside_literals_are_not_taint(path, source):
    assert "S003" not in rules(path, source)


@pytest.mark.parametrize(
    "path,source,secret",
    [
        ("a.py", 'private_key = "hidden-key-value"\neval(input())', "hidden-key-value"),
        (
            "a.ts",
            'const accessToken: string = "hidden-token-value";\neval(req.query.code);',
            "hidden-token-value",
        ),
        (
            "A.java",
            'class A { String privateKey = "hidden-key-value"; }',
            "hidden-key-value",
        ),
    ],
)
def test_secret_redaction_in_all_nearby_findings(path, source, secret):
    findings, _ = analyze_file(path, source)
    assert secret not in json.dumps(findings)
