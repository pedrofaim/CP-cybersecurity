# Sentinel SAST

Plataforma acadêmica de análise estática e DevSecOps, desenvolvida para o Projeto Integrador de Cybersecurity da FIAP. Interface em português, análise real com Python AST e Tree-sitter, quatro linguagens, nove famílias de regras, taint analysis intraprocedural, IA local opcional e Security Gate.

**Comece por [INICIAR_WINDOWS.md](INICIAR_WINDOWS.md).**

Interface 1.1: modo noturno, fontes IBM Plex locais e detalhes de código destacados. Para uma instalação existente, veja [LEIA_VISUAL_NOTURNO.md](LEIA_VISUAL_NOTURNO.md).

## O que você consegue fazer

- Colar código, enviar arquivos ou importar um ZIP autorizado.
- Analisar Python, JavaScript/JSX, TypeScript/TSX e Java.
- Visualizar severidade (vermelho para crítico, laranja para alto, amarelo para médio), índice de risco, histórico e arquivos com mais achados.
- Investigar a linha, CWE, evidência, fluxo origem → propagação → destino e orientação de correção.
- Pedir revisão semântica ao Ollama, com resposta estruturada, sugestão de código e indicação de possível falso positivo.
- Exportar JSON/SARIF e aplicar políticas por severidade no CLI e GitHub Actions.

Nenhum código recebido é importado, compilado para execução ou executado. Tree-sitter faz parsing; Python usa `ast.parse`.

## Execução recomendada: Docker

Requisitos locais: Docker Desktop com suporte a Compose; Python 3.11+ para gerar a configuração (ou edite `.env` manualmente com segredos próprios). A instalação inicial usa internet para imagens e pacotes. Após instalada, a análise determinística não necessita internet. Reserve aproximadamente 4 GB de RAM sem IA e 8 GB ou mais com IA; desempenho varia com a máquina.

**Atalho no Windows:** dois cliques em **ABRIR-SENTINEL.bat** fazem tudo (instalação, inicialização, navegador e chave copiada). `CRIAR-ATALHO-DESKTOP.bat` cria um atalho permanente na área de trabalho.

```powershell
cd sentinel-sast
py scripts/setup.py
docker compose up --build -d
```

Abra **http://localhost:8000**. Copie apenas o valor de `API_TOKEN` do arquivo `.env` para a tela de acesso. Não envie sua chave no chat nem ao repositório.

```powershell
docker compose ps
docker compose logs --tail=80 api worker
```

### Ativar IA local

```powershell
docker compose --profile ai up -d
docker compose exec ollama ollama pull llama3.2:3b
```

A primeira obtenção do modelo requer download de alguns GB. Selecione **Revisar com IA local** antes de iniciar uma análise. O worker envia até três achados de maior prioridade ao modelo; indisponibilidade é explícita e não inventa respostas. O modelo não altera o gate e não aplica patches. O schema exige severidade, explicação, remediação, código sugerido e possível falso positivo.

### Sem Docker: desenvolvimento

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe scripts/setup.py
.\.venv\Scripts\python.exe scripts/run_local.py
```

Esse modo usa SQLite e ThreadPoolExecutor. Para comprovar a arquitetura distribuída da entrega, use Docker com PostgreSQL, Redis e Celery. Sem Docker, o Ollama pode ser instalado separadamente e servir em `http://localhost:11434`.

## Demonstração rápida

1. Abra o painel e escolha **Experimentar laboratório**.
2. O motor analisa de verdade quatro exemplos deliberadamente vulneráveis.
3. Resultado esperado: **14 achados: 6 críticos, 7 altos e 1 médio**, gate bloqueado.
4. Abra **Vulnerabilidades**, filtre por linguagem e clique em SQL Injection.
5. Mostre origem, propagação, sink e recomendação de consulta parametrizada.
6. Analise `examples/safe` pelo CLI ou envie seus quatro arquivos ao dashboard: resultado esperado zero achados, gate aprovado.
7. Use o mesmo nome de projeto em análises futuras para formar a tendência. Não há histórico fictício pré-carregado.

## CLI e testes

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m sentinel.cli examples/vulnerable --output vulnerable.json --sarif vulnerable.sarif
.\.venv\Scripts\python.exe -m sentinel.cli examples/safe --output safe.json
.\.venv\Scripts\python.exe -m sentinel.cli sentinel --threshold high --output self.json
```

Códigos de saída: `0` aprovado, `1` bloqueado, `2` erro operacional. Erro de parsing ou ausência de arquivos analisados bloqueia o gate. A execução nos exemplos vulneráveis **deve retornar 1**.

API documentada em `/api/docs` (os endpoints de dados exigem cookie de sessão ou `Authorization: Bearer <API_TOKEN>`). Autenticação usa uma chave de instalação, não contas individuais.

## Estrutura

| Caminho | Responsabilidade |
|---|---|
| `sentinel/engine.py` | Parsers, regras estruturais e fluxo de dados |
| `sentinel/rules.py` | Catálogo, CWE, severidades e remediação |
| `sentinel/api.py` | Autenticação, uploads, API e dashboard |
| `sentinel/jobs.py` | Celery e modo local de desenvolvimento |
| `sentinel/storage.py` | PostgreSQL/SQLite com SQLAlchemy |
| `sentinel/ai.py` | Integração Ollama e validação da resposta |
| `sentinel/cli.py`, `reports.py` | Security Gate, JSON e SARIF |
| `web/` | Interface responsiva, sem dependências externas de frontend |
| `examples/` | Corpus vulnerável e controles corrigidos |
| `tests/` | Testes de regressão, contrato da IA e integração local |
| `.github/workflows/security.yml` | Gates, relatórios e smoke test de contêineres |
| `docs/` | Arquitetura, cobertura, defesa, rastreabilidade e validação |

## Escopo e validação

**85 testes passaram** no ambiente de desenvolvimento. Fluxos da interface foram verificados em Chromium com API real, nas resoluções desktop e celular; capturas estão em docs/evidence/ui/. O corpus pequeno serve como regressão, não como comprovação de precisão universal. Bandit não encontrou achados médios/altos no backend e scripts após os ajustes. O próprio Sentinel aprovou seu pacote Python.

**Pendente de validação no seu ambiente:** inicialização real do Docker Compose, fila Redis/Celery/PostgreSQL, inferência real do Ollama e execução remota dos workflows no GitHub. A interface 1.2 foi executada em Chromium headless com API real, conferida em desktop/mobile e inspecionada em capturas de tela. O workflow `containers` e `scripts/smoke_compose.py` foram incluídos para verificar a integração distribuída.

A implementação é uma base acadêmica funcional com cobertura declarada, não um substituto de Semgrep comercial/CodeQL nem uma promessa de nota máxima. Consulte [COBERTURA.md](docs/COBERTURA.md) para evitar alegar análise completa de todas as construções de cada linguagem.

## Segurança operacional

- API exposta apenas em `127.0.0.1`; PostgreSQL, Redis e Ollama sem portas publicadas.
- Chave de instalação gerada aleatoriamente, cookies HttpOnly/SameSite, validação de origem e CSP.
- Não extraímos ZIPs para disco; rejeitamos traversal, links simbólicos e volumes excessivos.
- Limites: 100 arquivos de código, 200 KB por arquivo e 2 MB de conteúdo total; ZIP com até 500 entradas.
- Dependências/pastas `.git`, `node_modules`, `.venv`, `venv`, `dist`, `build` são ignoradas em ZIP/CLI.
- Código integral permanece no banco somente enquanto a tarefa está pendente/em execução; a coluna é limpa ao finalizar ou falhar. Isso não garante remoção de backups ou páginas históricas do banco.
- Evidências permanecem no relatório; linhas identificadas com credenciais literais são mascaradas. Outros dados sensíveis e segredos fora dos padrões reconhecidos podem permanecer. Analise somente repositórios autorizados.
- Não publique esta instalação diretamente na internet. Uso multiusuário real requer identidade individual, autorização por projeto, TLS, auditoria, quotas distribuídas, criptografia/retensão e migrações de esquema.

## Fontes técnicas

Documento de requisitos fornecido pelo professor, consultado sem redistribuição no pacote. Referências primárias: [Python AST](https://docs.python.org/3/library/ast.html), [Tree-sitter Python](https://tree-sitter.github.io/py-tree-sitter/), [Ollama API](https://docs.ollama.com/api), [FastAPI](https://fastapi.tiangolo.com/), [Celery](https://docs.celeryq.dev/), [SARIF 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html), [Bandit](https://bandit.readthedocs.io/), [GitHub protected branches](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches).

## Entrega 1.2 - começar aqui

- `ABRIR-SENTINEL.bat`: **arquivo único de dois cliques** — instala, inicia, abre o painel e copia a chave. `CRIAR-ATALHO-DESKTOP.bat` fixa o atalho na área de trabalho.
- `COMECE_AQUI.html`: guia que abre com dois cliques, sem servidor.
- `VALIDAR_TUDO.bat`: prepara o ambiente e reproduz os testes, Bandit, gates e benchmark; evidências em docs/evidence-local.
- `docs/RELATORIO_TECNICO.pdf`: memorial, arquitetura, validação e roteiro de defesa.
- `benchmark/cases.json`: corpus rotulado com limites conhecidos e métricas reproduzíveis.
- `scripts/smoke_ai.py`: registra inferência real quando Ollama estiver instalado.

A nova revisão adiciona taint de caminhos/URLs em Java, destructuring básico em JS/TS, imports Node de comandos, isolamento de métodos, limite real de corpo HTTP e expiração de análises interrompidas. O top 5 ordena arquivos pela soma ponderada de severidades.
